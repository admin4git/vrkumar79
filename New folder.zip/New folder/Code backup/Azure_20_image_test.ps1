$VMName = "$($env:VMNAME)"
$COMPSER_BUILDID = "$($env:COMPSER_BUILDID)"
$VMDisk = "$VMName.vhd"
$imagedir = "/var/lib/osbuild-composer"

$secret = ""
$EncodedSecret = "$($env:azurestoragekey)"
#Write-Output "Received secret: $EncodedSecret"
if (![string]::IsNullOrWhiteSpace($EncodedSecret))
{
    $secret = [System.Text.Encoding]::Unicode.GetString([System.Convert]::FromBase64String($EncodedSecret))
}

if($VMName -eq "WZLXTGLDR8T1" -or $VMName -eq "WZLXTGLDR9T1") 
{
    Write-Output "Skipping image removal"
    Write-Output "Server Name :- $VMName"
}

connect-AzAccount -Identity -AccountId 4bf4b147-128d-41ef-9259-baae5335841a #wbgimagebuilder
select-AzSubscription -SubscriptionId "7b4d1501-6351-4d0f-a681-0473c2221a05" #WBG AZ ITSSM Prod Admin

$galleryName = "SecurityAccreditedGoldImages"
$imageDefinition = "RHEL8-Accredited-image-LVM"
$location = "East US"
$resourceGroup = 'WBG-OS-Image'
$VMLocalAdminUser = "azuser"
$VMLocalAdminSecurePassword = ConvertTo-SecureString "Ab123456Ab123456" -AsPlainText -Force
$Credential = New-Object System.Management.Automation.PSCredential ($VMLocalAdminUser, $VMLocalAdminSecurePassword)

#----list version with latest tag as of now it's not defined
#Write-Output "----------------------------------------------------------------------------------------"
#Get-AzGalleryImageVersion `
#    -ResourceGroupName $resourceGroup `
#    -GalleryName $galleryName `
#    -GalleryImageDefinitionName $imageDefinition `
#    | Select-Object Name, @{Name='IsLatest'; Expression={$_.PublishingProfile.IsLatest}}
#Write-Output "----------------------------------------------------------------------------------------"

Write-Output "Fetching latest image version from Azure Compute Gallery..."
$imageVersion = Get-AzGalleryImageVersion `
    -ResourceGroupName $resourceGroup `
    -GalleryName $galleryName `
    -GalleryImageDefinitionName $imageDefinition `
#    | Where-Object { $_.PublishingProfile.IsLatest -eq $true }
    | Sort-Object -Property Name -Descending `
    | Select-Object -First 1

if ($null -eq $imageVersion) {
    throw "Error: Could not find image version for '$imageDefinition' in gallery '$galleryName'"
    throw "Error: No image version marked as latest for '$imageDefinition' in gallery '$galleryName'."
}

$imageId = $imageVersion.Id

    $imagearray = $imageId.Split('/')
    $imagename = $imagearray[$imagearray.Count-1]

Write-Output "Using shared image gallery image: $imageId"

Write-Output "-- VM Name -- '$VMName'..."

Write-Output "Image Name == '$imagename' "

Write-Output "Image Name caps == '$IMAGENAME' "

Write-Output "##vso[task.setvariable variable=IMAGENAME;issecret=false;isOutput=true]$IMAGENAME"

<#
$vnet = Get-AzVirtualNetwork -Name wbgadmin-prod-pdmz-vnet
# Write-Output "Information about the vnets:"
# Write-Output $vnet
$subnet = $vnet.Subnets | Where-Object { $_.Name -eq "misc" }
# Write-Output "Information about the subnet:"
# Write-Output $subnet
Write-Output "Creating new Network Interface '$VMName-nic' for the test VM..."
$nic = New-AzNetworkInterface -Name "$VMName-nic" -ResourceGroupName $resourceGroup -Location $location -SubnetId $subnet.Id -Force

Write-Output "Creating new VM '$VMName' using shared gallery image..."
$vmConfig = New-AzVMConfig -VMName $VMName -VMSize Standard_D2s_v5 -SecurityType Standard `
    | Set-AzVMOperatingSystem -Linux -ComputerName $VMName -Credential $Credential `
    | Set-AzVMSourceImage -Id $imageId `
    | Set-AzVMBootDiagnostic -Disable `
    | Add-AzVMNetworkInterface -Id $nic.Id

Write-Output "Creating new VM '$VMName'..."

New-AzVM -ResourceGroupName $resourceGroup -Location $location -VM $vmConfig

$ipaddress = $($nic.IpConfigurations[0].PrivateIpAddress)

Write-Output "$VMNAME is powered on and the ip address is $ipaddress"
#>
Write-Host "##vso[task.setvariable variable=IMAGE_ID;issecret=false;isOutput=true]$($image.Id)"
Write-Host "##vso[task.setvariable variable=TESTVM_IP;issecret=false;isOutput=true]$($ipaddress)"

$obj = New-Object psobject
$obj | Add-Member ImageID $image.Id
$obj | Add-Member OSVersion $($env:OSVersion)
$obj | Add-Member VMSS $($env:VMSS)
$obj | Add-Member VMNAME $($env:VMNAME)
$transporter = $obj | ConvertTo-Json
$transporter | Set-Content variable.json