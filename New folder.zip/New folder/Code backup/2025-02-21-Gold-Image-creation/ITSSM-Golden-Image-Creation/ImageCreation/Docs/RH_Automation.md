<div id="top"></div>

<!-- TABLE OF CONTENTS -->
<details>
  <summary>Table of Contents</summary>
  <ol>
    <li>
      <a href="#redhat-image-builder-automation">RedHat Image Builder Automation</a>
      <ul>
        <li><a href="#diagram">Diagram</a></li>
        <li><a href="#components">Components</a></li>
      </ul>
      <a href="#redhat-image-builder-lifecycle">RedHat Image Builder Lifecycle</a>
      <ul>
        <li><a href="#rhel9.toml">rhel9.toml</a></li>
        <li><a href="#Script">Scripts</a></li>
      </ul>
    </li>
  </ol>
</details>

<!-- GETTING STARTED -->
## Diagram

- **RedHat Image Builder Automation Diagram**       
    ![Diagram](pics/Red_Hat_image_builder_diagram.jpg)           
    <br/><br/>
RedHat Image Builder Automation uses Red Hat image builder tool.You can use image builder to create customized RHEL images,    
including system images prepared for deployment on cloud platforms. Image builder automatically handles the setup details for each output type    
and is therefore easier to use and faster to work with than manual methods of image creation. You can access the image builder functionality through a command-line interface in the composer-cli tool, or a graphical user interface in the RHEL web console.More details here: https://access.redhat.com/documentation/en-us/red_hat_enterprise_linux/8/html/composing_a_customized_rhel_system_image/composer-description_composing-a-customized-rhel-system-image
## Components
We have following components in RedHat Image Builder service:
- <a href="https://dev.azure.com/ITSEN-Collection/Enterprise-Services/_git/ITSSM-Systems-Engineering?path=/ImageCreation/ImageCreation2.0">AzureDevops repository "ITSSM/ImageCreation2.0"</a>
- <a href="https://dev.azure.com/ITSEN-Collection/Enterprise-Services/_build?definitionId=458">AWS Golden Image Creation pipeline
- <a href="https://dev.azure.com/ITSEN-Collection/Enterprise-Services/_build?definitionId=467">Azure Golden Image Creation pipeline
- <a href="https://dev.azure.com/ITSEN-Collection/Enterprise-Services/_build?definitionId=476">VmWare Golden Image Creation pipeline
- <a href="https://dev.azure.com/ITSEN-Collection/Enterprise-Services/_git/ITSSM-Systems-Engineering?path=/ImageCreation/ImageCreation2.0/Scripts/00_LoadKeyvaultVariables.ps1">KeyVault

#### AzureDevops repository "ITSSM/ImageCreation2.0"

Repository has three folders: **CI** folder contains configuration for AWS, Azure and VmWare pipelines.**Scripts** and **Hardening** folders contain code for build, deploy, upload and test the image.


![ImageCreation2.0](pics/ImageCreation2.0_structure.PNG)            
<br/><br/>
<p align="right">(<a href="#top">back to top</a>)</p>

#### All pipelines are triggred:
- manually
- pipeline cron job

#### AWS Golden Image Creation pipeline

When configuration for AWS part is updated **AWS Golden Image Creation pipeline** the pipeline is triggered : 

![ImageCreation2.0](pics/manually_pipeline.PNG)            
<br/><br/>
<p align="right">(<a href="#top">back to top</a>)</p>

. It loads <a href="https://dev.azure.com/ITSEN-Collection/Enterprise-Services/_git/ITSSM-Systems-Engineering?path=/ImageCreation/ImageCreation2.0/Scripts">Scripts directory</a> and starts building the image on our AWS agent walxpgldagnt02 located as EC2 instance in ASW Admin account.Once the image is built locally on the agent RedHaT Image builder tool uploads it to <a href="arn:aws:cloudformation:us-east-1:567839857739:stack/SC-567839857739-pp-7r4vg2upkjble/536304f0-03bb-11ee-a0ed-0ef955cdaac5">'wbgadmin-rh-builder' S3 bucket</a> and automaticly deploy the image to as EC2 snapshot.Later on the pipeline creates EC2 instance and performs Nessus scan and if security tests are passed as a next step it converts the image as EC2 AMI with tag 'IMAGE_KEY'.


![ImageCreation2.0](pics/pipeline_tasks.PNG)            
<br/><br/>
<p align="right">(<a href="#top">back to top</a>)</p>

#### Azure Golden Image Creation pipeline

When configuration for Azure part is updated **Azure Golden Image Creation pipeline** the pipeline is triggered:

![ImageCreation2.0](pics/azure_pipeline.PNG)            
<br/><br/>
<p align="right">(<a href="#top">back to top</a>)</p>

 It loads <a href="https://dev.azure.com/ITSEN-Collection/Enterprise-Services/_git/ITSSM-Systems-Engineering?path=/ImageCreation/ImageCreation2.0/Scripts">Scripts directory</a> and starts building the image on our Azure agent wzlxpgldagnt02 located in Azure Admin subscription.Once the image is built locally on the agent RedHaT Image builder tool uploads it to <a href="https://wbgosbuildimagestorage.blob.core.windows.net/rhelimages">'wbgosbuildimagestorage' Azure Storage container</a> and automaticly creates image file, creates Azure VM and performs Nessus scan and if security tests are passed the image is uploaded to Image Gallery.


#### VmWare Golden Image Creation pipeline

When configuration for VmWare part is updated **VmWare Golden Image Creation pipeline** the pipeline is triggered:

![ImageCreation2.0](pics/vmware_pipeline.PNG)            
<br/><br/>
<p align="right">(<a href="#top">back to top</a>)</p>

 It loads <a href="https://dev.azure.com/ITSEN-Collection/Enterprise-Services/_git/ITSSM-Systems-Engineering?path=/ImageCreation/ImageCreation2.0/Scripts">Scripts directory</a> and starts building the image on our VmWare VM agnet xxx located as VM in production VmWare Vcenter.Once the image is created the pipeline creates tst VM and performs Nessus scan and if security tests are passed the image is uploaded to VmWare Library in Test VmWare Vcenter.And it automatically is moved to production


#### Azure KeyVault

All secrets are stored in /subscriptions/7b4d1501-6351-4d0f-a681-0473c2221a05/resourceGroups/WBG-OS-Image/providers/Microsoft.KeyVault/vaults/wbggoldimagecreation.

### RedHat Image Builder Lifecycle


## rhel9.toml
rhel9.toml is the main configuration file for RedHat Image builder tool which is used for AWS, Azure and VmWare images. This config file is used to create blueprints and later on to create an image.
In rhel9.toml there is on option to define different system configurations which are going to be implemented in the image like package, system files, users, ect.


![toml](pics/rhel9-toml.PNG)            
<br/><br/>
<p align="right">(<a href="#top">back to top</a>)</p>
