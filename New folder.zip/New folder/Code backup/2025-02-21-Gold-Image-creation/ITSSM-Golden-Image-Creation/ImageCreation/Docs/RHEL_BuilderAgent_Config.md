#####As root
rpm --import https://packages.microsoft.com/keys/microsoft.asc
dnf install -y https://packages.microsoft.com/config/rhel/9.0/packages-microsoft-prod.rpm
yum install -y tmux powershell mc git jq vim wget createrepo python3.9 python3.11 python3-pip python3.11-pip yum-utils

yum-config-manager --add-repo https://rpm.releases.hashicorp.com/RHEL/hashicorp.repo
yum install -y terraform

#update python version in case
ls -ls /usr/bin/python*
alternatives --set python /usr/bin/python3
sudo ln -sf /usr/bin/python3.9 /usr/bin/python3
python --version
useradd srvtfs -g srvtfs

###On AWS
curl "https://awscli.amazonaws.com/awscli-exe-linux-x86_64.zip" -o "awscliv2.zip"
unzip awscliv2.zip
./aws/install
###On VMWare
curl -L -o - "https://github.com/vmware/govmomi/releases/latest/download/govc_$(uname -s)_$(uname -m).tar.gz" | tar -C /usr/local/bin -xvzf - govc
###On Azure
dnf install azure-cli -y
su srvtfs 
pwsh
##################### TROUBLESHOOTING ##################
Error can happen during module install if the srvtfs user has no access to /tmp/Microsoft.PackageManagement. Delete the folder and get it recreated as srvtfs by installing the modules from that user.
########################################################
Set-PSRepository -Name PSGallery -InstallationPolicy Trusted
Install-Module -Name Az.ImageBuilder
Install-Module Az
#########################
lsblk
#####IF DATAVG EXISTS ##############
umount /dev/mapper/Datavg-Datavol
vgremove /dev/Datavg -y
vi /etc/fstab
# Delete line /dev/mapper/Datavg-Datavol /Data xfs rw,seclabel,relatime,attr2,inode64,logbufs=8,logbsize=32k,noquota 0 0
##### end IF DATAVG EXISTS #########
vgcreate osbuild /dev/sdX
lvcreate -L 25G -n var_cache_osbuild-composer osbuild -y
lvcreate -L 25G -n var_cache_osbuild-worker osbuild -y 
lvcreate -l 100%FREE -n var_lib_osbuild-composer osbuild -y

mkfs.xfs /dev/osbuild/var_cache_osbuild-composer
mkfs.xfs /dev/osbuild/var_cache_osbuild-worker
mkfs.xfs /dev/osbuild/var_lib_osbuild-composer

mkdir /var/lib/osbuild-composer/
mkdir /var/cache/osbuild-composer/
mkdir /var/cache/osbuild-worker/

################### SCRIPTED WAY FOR DISK CONFIGURATION ###################
function Create-DiskConfiguration
{
    param(
        $disktype
    )
	
    $diskname = ""
    $disklocation = ""
    $mountpath = ""

    switch ($disktype) 
    {
        "lib-osbuild-composer"
        {
            $mountpath = "var-lib-osbuild\\x2dcomposer.mount"
            $verifypath = "var-lib-osbuild\x2dcomposer.mount"
            $diskname = "var_lib_osbuild-composer"
            $disklocation = "/var/lib/osbuild-composer"
        }
        "cache-osbuild-composer"
        {
            $mountpath = "var-cache-osbuild\\x2dcomposer.mount"
            $verifypath = "var-cache-osbuild\x2dcomposer.mount"
            $diskname = "var_cache_osbuild-composer"
            $disklocation = "/var/cache/osbuild-composer"
        }
        "cache-osbuild-worker"
        {
            $mountpath = "var-cache-osbuild\\x2dworker.mount"
            $verifypath = "var-cache-osbuild\x2dworker.mount"
            $diskname = "var_cache_osbuild-worker"
            $disklocation = "/var/cache/osbuild-worker"
        }
    }
	
    $diskid = ls -l /dev/osbuild/$diskname
    $diskid = $diskid.Substring($diskid.LastIndexOf("../") + 3)
    $diskuuid = ls -l /dev/disk/by-uuid/ | grep $diskid
    $endindex = $diskuuid.LastIndexOf(" ->")
    $startindex = $diskuuid.IndexOf(":") + 4
    $diskuuid = $diskuuid.Substring($startindex, $endindex - $startindex)
    $diskuuidesc = systemd-escape dev/disk/by-uuid/$diskuuid

    $filecontent = @"
[Unit]
Documentation=man:fstab(5) man:systemd-fstab-generator(8)
Before=local-fs.target
# Mount only after the disk was probed
# replace dashes in the uuid entry with \x2d sequence or use systemd-escape bianry to get it for you
After=blockdev@$($diskuuidesc).target

[Mount]
What=/dev/disk/by-uuid/$diskuuid
Where=$disklocation
Type=xfs
Options=defaults,nodev,nosuid

[Install]
WantedBy=multi-user.target
"@

    bash -c "echo '$filecontent' > /etc/systemd/system/$mountpath"
    systemctl daemon-reload
    systemctl enable --now $verifypath
    df -h $disklocation
    systemctl is-enabled $verifypath
    systemctl is-active  $verifypath
}


Create-DiskConfiguration -disktype "lib-osbuild-composer"
Create-DiskConfiguration -disktype "cache-osbuild-composer"
Create-DiskConfiguration -disktype "cache-osbuild-worker"
################### end SCRIPTED WAY FOR DISK CONFIGURATION ###################


#Example to get the disk uuid and manual disk configuration
[root@wzlxpgldagnt02 system]# ls -l /dev/osbuild/var_lib_osbuild-composer
lrwxrwxrwx 1 root root 7 Nov 15 04:41 /dev/osbuild/var_lib_osbuild-composer -> ../dm-7
[root@wzlxpgldagnt02 system]# ls -l /dev/disk/by-uuid/ | grep dm\-7
lrwxrwxrwx 1 root root 10 Nov 15 04:41 f285d4fc-52e1-4e9e-ab16-34dc1c21b5eb -> ../../dm-7

systemd-escape dev/disk/by-uuid/###UUID###

# Mountpoint service:
vim /etc/systemd/system/var-lib-osbuild\x2dcomposer.mount

############################################################
[Unit]
Documentation=man:fstab(5) man:systemd-fstab-generator(8)
Before=local-fs.target
# Mount only after the disk was probed
# replace dashes in the uuid entry with \x2d sequence or use systemd-escape bianry to get it for you
After=blockdev@###systemd-escape-result###.target

[Mount]
What=/dev/disk/by-uuid/###UUID###
Where=/var/lib/osbuild-composer
Type=xfs
Options=defaults,nodev,nosuid

[Install]
WantedBy=multi-user.target

############################################################

systemctl daemon-reload
systemctl enable --now 'var-lib-osbuild\x2dcomposer.mount'

Verification:
[root@wzlxpgldagnt02 system]# systemctl is-enabled 'var-lib-osbuild\x2dcomposer.mount'
enabled
[root@wzlxpgldagnt02 system]# systemctl is-active 'var-lib-osbuild\x2dcomposer.mount'
active
[root@wzlxpgldagnt02 system]# df -h /var/lib/osbuild-composer/
Filesystem                                     Size  Used Avail Use% Mounted on
/dev/mapper/osbuild-var_lib_osbuild--composer  150G  1.1G  149G   1% /var/lib/osbuild-composer

[root@wzlxpgldagnt02 system]# ls -l /dev/osbuild/var_cache_osbuild-composer
lrwxrwxrwx 1 root root 7 Nov 15 04:41 /dev/osbuild/var_cache_osbuild-composer -> ../dm-5
[root@wzlxpgldagnt02 system]# ls -l /dev/disk/by-uuid/ | grep dm\-5
lrwxrwxrwx 1 root root 10 Nov 15 04:41 e6830113-0baa-466e-a6b7-081d25e9a885 -> ../../dm-5
systemd-escape dev/disk/by-uuid/###UUID###

# Mountpoint service:
vim '/etc/systemd/system/var-cache-osbuild\x2dcomposer.mount'

############################################################
[Unit]
Documentation=man:fstab(5) man:systemd-fstab-generator(8)
Before=local-fs.target
# Mount only after the disk was probed
# replace dashes in the uuid entry with \x2d sequence or use systemd-escape bianry to get it for you
After=blockdev@###systemd-escape-result###.target

[Mount]
What=/dev/disk/by-uuid/###UUID###
Where=/var/cache/osbuild-composer
Type=xfs
Options=defaults,nodev,nosuid

[Install]
WantedBy=multi-user.target

############################################################

# Mounting
[root@wzlxpgldagnt02 system]# systemctl daemon-reload
[root@wzlxpgldagnt02 system]# systemctl enable --now var-cache-osbuild\\x2dcomposer.mount

# Verification:
[root@wzlxpgldagnt02 system]# systemctl is-enabled var-cache-osbuild\\x2dcomposer.mount
enabled
[root@wzlxpgldagnt02 system]# systemctl is-active var-cache-osbuild\\x2dcomposer.mount
active
[root@wzlxpgldagnt02 system]# df -h /var/cache/osbuild-composer/
Filesystem                                       Size  Used Avail Use% Mounted on
/dev/mapper/osbuild-var_cache_osbuild--composer   25G  211M   25G   1% /var/cache/osbuild-composer

[root@wzlxpgldagnt02 system]# ls -l /dev/osbuild/var_cache_osbuild-worker
lrwxrwxrwx 1 root root 7 Nov 15 04:41 /dev/osbuild/var_cache_osbuild-worker -> ../dm-6
[root@wzlxpgldagnt02 system]# ls -l /dev/disk/by-uuid/ | grep dm\-6
lrwxrwxrwx 1 root root 10 Nov 15 04:41 6945f1e0-35bc-4796-900b-50ac686ec984 -> ../../dm-6
systemd-escape dev/disk/by-uuid/###UUID###

# Mountpoint service:
vim '/etc/systemd/system/var-cache-osbuild\x2dworker.mount'

############################################################
[Unit]
Documentation=man:fstab(5) man:systemd-fstab-generator(8)
Before=local-fs.target
# Mount only after the disk was probed
# replace dashes in the uuid entry with \x2d sequence or use systemd-escape bianry to get it for you
After=blockdev@###systemd-escape-result###.target

[Mount]
What=/dev/disk/by-uuid/###UUID###
Where=/var/cache/osbuild-worker
Type=xfs
Options=defaults,nodev,nosuid

[Install]
WantedBy=multi-user.target

############################################################

systemctl daemon-reload
systemctl enable --now var-cache-osbuild\\x2dworker.mount

VERIFICATION:
[root@wzlxpgldagnt02 system]# df -h /var/cache/osbuild-worker/
Filesystem                                     Size  Used Avail Use% Mounted on
/dev/mapper/osbuild-var_cache_osbuild--worker   25G  211M   25G   1% /var/cache/osbuild-worker
[root@wzlxpgldagnt02 system]# systemctl is-enabled var-cache-osbuild\\x2dworker.mount
enabled
[root@wzlxpgldagnt02 system]# systemctl is-active var-cache-osbuild\\x2dworker.mount
active

yum install osbuild-composer composer-cli -y
systemctl enable --now osbuild-composer.socket
curl https://chefdownload-commercial.chef.io/install.sh?license_id=ba7ba1e7-733c-4e77-8052-ae49aa1df4dd | bash -s -- -P inspec

usermod -aG weldr srvtfs
mkdir /Data
chown srvtfs: /Data/
chmod 755 /Data/
su srvtfs 
inspec license add
####Install python packages
python3.11 -m pip install requests paramiko
cd /Data
mkdir tfsagent
cd tfsagent/
mkdir 01
cd 01/
wget agent from the portal https://dev.azure.com/ITSEN-Collection/Enterprise-Services/_settings/agentqueues?queueId=3393&view=agents
./config.sh
Server: https://dev.azure.com/ITSEN-Collection
Agent pool: ITSSM Gold Image
Agent name:
	OnPrem01Agent01
	OnPrem02Agent01
	Azure01Agent01
	Azure01Agent02
	Azure02Agent01
	Azure02Agent02
	Amazon01Agent01
	Amazon02Agent01
	AzureTest01Agent01
	AzureTest02Agent01
######################back to root user
mkdir /var/lib/osbuild-composer/govc
chown srvtfs: /var/lib/osbuild-composer/govc
chmod 755 /var/lib/osbuild-composer/govc
cd /Data/tfsagent/01/
./svc.sh install srvtfs
./svc.sh start
mkdir /Data/REPO
cd /Data/REPO/
curl  https://packages.chef.io/repos/yum/stable/el/9/x86_64/chef-18.3.0-1.el9.x86_64.rpm > chef-18.3.0-1.el9.x86_64.rpm
wget http://w0lxsatellite01.worldbank.org/pub/katello-ca-consumer-latest.noarch.rpm
mv katello-ca-consumer-latest.noarch.rpm katello-ca-consumer-w0lxsatellite01.worldbank.org.rpm
createrepo .
cd ..
chown _osbuild-composer: REPO -R
cd /root/
vim local_repo.toml

##################################

check_gpg = false
check_repogpg = false
check_ssl = false
id = "local_repo"
name = "local_repo"
rhsm = false
system = false
type = "yum-baseurl"
url = "file:///Data/REPO/"

##################################
composer-cli sources add local_repo.toml

setfacl --recursive -m srvtfs:rwx /etc/rhsm/
setfacl --recursive -m srvtfs:rwx /Data/REPO/
setfacl --recursive -m srvtfs:rwx /var/cache/osbuild-worker/
setfacl --recursive -m srvtfs:rwx /var/cache/osbuild-composer/
setfacl --recursive -m srvtfs:rwx /var/lib/osbuild-composer/artifacts/

visudo
vi /etc/sudoers.d/srvtfs
%srvtfs ALL=NOPASSWD:/usr/bin/chattr *
%srvtfs ALL=NOPASSWD:/usr/sbin/subscription-manager *
%srvtfs ALL=NOPASSWD:/usr/bin/yum reinstall packages-microsoft-prod.rpm -y
%srvtfs ALL=NOPASSWD:/usr/bin/yum check-update
%srvtfs ALL=NOPASSWD:/usr/bin/chown _osbuild-composer\: REPO -R
%srvtfs ALL=NOPASSWD:/usr/bin/createrepo .
%srvtfs ALL=NOPASSWD:/usr/bin/systemctl restart osbuild-composer.service
%srvtfs ALL=NOPASSWD:/usr/bin/rm -rf /Data/REPO/*
%srvtfs ALL=NOPASSWD:/usr/bin/systemctl stop osbuild\*
%srvtfs ALL=NOPASSWD:/usr/bin/systemctl reset-failed osbuild\*
%srvtfs ALL=NOPASSWD:/usr/bin/systemctl start osbuild-composer.socket
%srvtfs ALL=NOPASSWD:/usr/bin/rm -rf /var/cache/osbuild-worker/*
%srvtfs ALL=NOPASSWD:/usr/bin/rm -rf /var/cache/osbuild-composer/*
%srvtfs ALL=NOPASSWD:/usr/bin/rm -rf /var/lib/osbuild-composer/artifacts/*