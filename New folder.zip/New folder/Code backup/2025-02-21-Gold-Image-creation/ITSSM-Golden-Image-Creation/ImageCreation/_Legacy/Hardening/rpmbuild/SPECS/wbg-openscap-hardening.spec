Name:           wbg-openscap-hardening
Version:        0.0.4
Release:        1%{?dist}
Summary:        "Installs openSCAP remediation script and remediates the system"
BuildArch:      noarch

License:        GPL
URL:            https://dev.azure.com/ITSEN-Collection/Enterprise-Services/_git/ITSSM-Systems-Engineering?path=/ImageCreation/ImageCreation2.0/Hardening
Source0:        %{name}-%{version}.tar.gz

Requires:       (bash and scap-security-guide and openscap-scanner and openscap-utils and libxml2 and coreutils)

%description
Deploys openscap remediation script and it's dependencies.

%prep
%setup -q


%install
rm -rf $RPM_BUILD_ROOT
mkdir -p $RPM_BUILD_ROOT/usr/local/bin/
mkdir -p $RPM_BUILD_ROOT/%{_sysconfdir}/WBG/openscap/exceptions/
install -m 700 openscap_remediation.sh $RPM_BUILD_ROOT/usr/local/bin/openscap_remediation.sh
install -m 600 override.global $RPM_BUILD_ROOT/%{_sysconfdir}/WBG/openscap/exceptions/override.global
install -m 600 variables.global $RPM_BUILD_ROOT/%{_sysconfdir}/WBG/openscap/exceptions/variables.global

%post
if [ $1 == 1 ]
then
    echo "@reboot root /usr/local/bin/openscap_remediation.sh -r ; /usr/bin/sed -i '/openscap_remediation.sh/d' /etc/crontab" >> /etc/crontab
fi

%files
%attr(0600, root, root) %{_sysconfdir}/WBG/openscap/exceptions/override.global
%attr(0600, root, root) %{_sysconfdir}/WBG/openscap/exceptions/variables.global
%attr(0700, root, root) /usr/local/bin/openscap_remediation.sh

%license gpl-3.0.txt

%changelog
* Thu Jun 08 2023 Strahil Nikolov <snikolov@worldbankgroup.org>
- Change the scheduling to use /etc/crontab (for RH Image Builder)

* Tue Jun 06 2023 Strahil Nikolov <snikolov@worldbankgroup.org>
- Disable xccdf_org.ssgproject.content_rule_sysctl_net_ipv4_conf_all_rp_filter
- Disable xccdf_org.ssgproject.content_rule_sysctl_net_ipv4_conf_default_rp_filter
- Schedule execution of remediation via 'systemd-run --on-boot' when package is installed

* Tue Apr 18 2023 Strahil Nikolov <snikolov@worldbankgroup.org>
- Initial Development
