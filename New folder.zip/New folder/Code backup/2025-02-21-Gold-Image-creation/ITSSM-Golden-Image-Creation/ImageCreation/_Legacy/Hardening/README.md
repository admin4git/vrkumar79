# Prerequisites    
  ```sh
  # Install the deps on a RHEL9 system
  dnf install -y rpmdevtools rpmlint
  ```

# Make your changes to the sources as a **regular** user    
```sh
   export NEW_RPM_VERSION='0.0.2'
   cp -a rpmbuild/SOURCES/wbg-openscap-hardening*.tar.gz ~
   cd ~
   tar -xzvf wbg-openscap-hardening*.tar.gz
   mv wbg-openscap-hardening* wbg-openscap-hardening-${NEW_RPM_VERSION}
   cd wbg-openscap-hardening-${NEW_RPM_VERSION}
```

# Validate the SPEC file as a **regular** user
```sh
    # Any hard errors should be addressed, the following warnings are expected 
    [myuser@rhel9system ~]$ rpmlint rpmbuild/SPECS/wbg-openscap-hardening.spec
    rpmbuild/SPECS/wbg-openscap-hardening.spec: W: no-%build-section
    rpmbuild/SPECS/wbg-openscap-hardening.spec: W: invalid-url Source0: wbg-openscap-hardening-0.0.1.tar.gz
    0 packages and 1 specfiles checked; 0 errors, 2 warnings.
```

# Build your rpm as a **regular** user    
```sh
   ls -ld wbg-openscap-hardening-${NEW_RPM_VERSION}
   tar -czvf wbg-openscap-hardening-${NEW_RPM_VERSION}.tar.gz wbg-openscap-hardening-${NEW_RPM_VERSION}
   mv wbg-openscap-hardening-${NEW_RPM_VERSION}.tar.gz rpmbuild/SOURCES/
   rpmbuild -bb rpmbuild/SPECS/wbg-openscap-hardening.spec
```
