$VMName = "$($env:VMNAME)"
$COMPSER_BUILDID = "$($env:COMPSER_BUILDID)"
$VMDisk = "$VMName.vhd"
$imagedir = "/var/lib/osbuild-composer"

$secret = ""
$EncodedSecret = "$($env:azurestoragekey)"
#Write-Output "Received secret: $EncodedSecret"
if (![string]::IsNullOrWhiteSpace($EncodedSecret))
{
    $secret = [System.Text.Encoding]::Unicode.GetString([System.Convert]::FromBase64String($EncodedSecret))
}

if($VMName -eq "WZLXTGLDR8T1" -or $VMName -eq "WZLXTGLDR9T1") 
{
    Write-Output "Skipping image removal"
}
else 
{
    Remove-Item -Recurse -Force "$imagedir/govc/$VMNAME.vmdk" -ErrorAction SilentlyContinue
    Write-Output "Trying to downloading image file to $imagedir/govc/$VMNAME.vmdk..."
    composer-cli compose image "$COMPSER_BUILDID" --filename "$imagedir/govc/$VMNAME.vmdk" -j
    Write-Output "Removing composed osbuild image $COMPSER_BUILDID..."
    composer-cli compose delete "$COMPSER_BUILDID" -j   
    Write-Output "Converting built image $VMName..."
    qemu-img convert "$imagedir/govc/$VMName.vmdk" -O vpc -o subformat=fixed "$imagedir/govc/$VMDisk"
}

connect-AzAccount -Identity -AccountId 4bf4b147-128d-41ef-9259-baae5335841a #wbgimagebuilder
select-AzSubscription -SubscriptionId "7b4d1501-6351-4d0f-a681-0473c2221a05" #WBG AZ ITSSM Prod Admin

Write-Output "Uploading built disk $VMDisk..."
$ctx = New-AzStorageContext -StorageAccountName wbgosbuildimagestorage  -StorageAccountKey $secret
Set-AzStorageBlobContent -File "$imagedir/govc/$VMDisk" -Container rhelimages -Blob $VMDisk -Context $ctx -BlobType Page -Force

$location = "East US"
$resourceGroup = 'WBG-OS-Image'
$VMLocalAdminUser = "azuser"
$VMLocalAdminSecurePassword = ConvertTo-SecureString "Ab123456Ab123456" -AsPlainText -Force
$Credential = New-Object System.Management.Automation.PSCredential ($VMLocalAdminUser, $VMLocalAdminSecurePassword)
$existingimage = Get-AzImage -Name $VMName
if ($null -ne $existingimage)
{
    Remove-AzImage -ResourceGroupName $existingimage.ResourceGroupName -ImageName $existingimage.Name -Force
}
$imageConfig = New-AzImageConfig -Location $location -HyperVGeneration V2
$osDiskVhdUri = "https://wbgosbuildimagestorage.blob.core.windows.net/rhelimages/$VMDisk"
Set-AzImageOsDisk -Image $imageConfig -OsType Linux -OsState 'Generalized' -BlobUri $osDiskVhdUri
Write-Output "Creating new Image '$VMName' from the created disk..."
$image = New-AzImage -Image $imageConfig -ImageName $VMName -ResourceGroupName $resourceGroup

$vnet = Get-AzVirtualNetwork -Name wbgadmin-prod-pdmz-vnet
# Write-Output "Information about the vnets:"
# Write-Output $vnet
$subnet = $vnet.Subnets | Where-Object { $_.Name -eq "misc" }
# Write-Output "Information about the subnet:"
# Write-Output $subnet
Write-Output "Creating new Network Interface '$VMName-nic' for the test VM..."
$nic = New-AzNetworkInterface -Name "$VMName-nic" -ResourceGroupName $resourceGroup -Location $location -SubnetId $subnet.Id -Force
$vmConfig = New-AzVMConfig -VMName $VMName -VMSize Standard_D2s_v5 -SecurityType Standard | Set-AzVMOperatingSystem -Linux -ComputerName $VMName -Credential $Credential | Set-AzVMSourceImage -Id $image.Id | Set-AzVMBootDiagnostic -Disable | Add-AzVMNetworkInterface -Id $nic.Id

#$vmConfig = New-AzVMConfig -VMName $VMName -VMSize Standard_D2s_v5 | Set-AzVMOperatingSystem -Linux -ComputerName $VMName -Credential $Credential | Set-AzVMSourceImage -Id $image.Id | Set-AzVMBootDiagnostic -Disable | Add-AzVMNetworkInterface -Id $nic.Id
#$vmConfig = Set-AzVMSecurityProfile -VM $vmConfig -SecurityType "TrustedLaunch"
#$vmConfig = Set-AzVMUefi -VM $vmConfig -EnableVtpm $true -EnableSecureBoot $true

Write-Output "Creating new VM '$VMName'..."
New-AzVM -ResourceGroupName $resourceGroup -Location $location -VM $vmConfig

$ipaddress = $($nic.IpConfigurations[0].PrivateIpAddress)

Write-Output "$VMNAME is powered on and the ip address is $ipaddress"

Write-Host "##vso[task.setvariable variable=IMAGE_ID;issecret=false;isOutput=true]$($image.Id)"
Write-Host "##vso[task.setvariable variable=TESTVM_IP;issecret=false;isOutput=true]$($ipaddress)"

$obj = New-Object psobject
$obj | Add-Member ImageID $image.Id
$obj | Add-Member OSVersion $($env:OSVersion)
$obj | Add-Member VMSS $($env:VMSS)
$obj | Add-Member VMNAME $($env:VMNAME)
$transporter = $obj | ConvertTo-Json
$transporter | Set-Content variable.json
