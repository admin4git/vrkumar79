#!/bin/bash

# Set variables
S3_BUCKET_NAME="wbgadmin-rh-builder"
IMAGE_NAME="${VMNAME}"
AMI_ID=$(aws ec2 describe-images --filters "Name=name,Values=${IMAGE_NAME}" --query 'Images[*].ImageId' --output text)
SNAPSHOT_ID=$(aws ec2 describe-snapshots --filters "Name=tag:Name,Values=${IMAGE_NAME}" --query 'Snapshots[*].SnapshotId' --output text)
INSTANCE_ID=$(aws ec2 describe-instances --filters "Name=tag:Name,Values=RhImageBuilderTestMachine" --query "Reservations[].Instances[].InstanceId" --output text)

# Check if image exists in S3 bucket
if aws s3 ls "s3://${S3_BUCKET_NAME}/${IMAGE_NAME}" 2>&1 | grep -q 'NoSuchBucket\|NoSuchKey'; then
  echo "Image not found in S3 bucket"
else
  # Delete image from S3 bucket
  aws s3 rm "s3://${S3_BUCKET_NAME}/${IMAGE_NAME}"
  echo "Image deleted from S3 bucket"
fi

# Deregister AMI
if [ -z "$AMI_ID" ]; then
  echo "AMI ID is empty"
else
  if aws ec2 describe-images --image-ids "${AMI_ID}" 2>&1 | grep -q 'InvalidAMIID.NotFound'; then
    echo "AMI not found"
  else
    aws ec2 deregister-image --image-id "${AMI_ID}"
    echo "AMI deregistered"
  fi
fi

# Delete snapshot
if [ -z "$SNAPSHOT_ID" ]; then
  echo "SNAPSHOT_ID is empty"
else
  for SNAP in $SNAPSHOT_ID
  do
    if aws ec2 describe-snapshots --snapshot-ids "${SNAP}" 2>&1 | grep -q 'InvalidSnapshot.NotFound'; then
      echo "Snapshot ${SNAP} not found"
    else
      aws ec2 delete-snapshot --snapshot-id "${SNAP}"
      echo "Snapshot ${SNAP} deleted"
    fi
  done
fi

# Terminate EC2 instances
if [ -z "$INSTANCE_ID" ]; then
  echo "INSTANCE_ID is empty"
else
  for INSTANCE in $INSTANCE_ID
  do
    if aws ec2 describe-instances --instance-ids "${INSTANCE}" 2>&1 | grep -q 'InvalidInstanceID.NotFound'; then
      echo "Instance ${INSTANCE} not found"
    else
      aws ec2 terminate-instances --instance-ids "${INSTANCE}"
      echo "Instance ${INSTANCE} terminated"
    fi
  done
fi
