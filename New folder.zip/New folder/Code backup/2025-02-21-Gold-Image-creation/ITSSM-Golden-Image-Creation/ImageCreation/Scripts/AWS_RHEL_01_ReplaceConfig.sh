#!/usr/bin/bash

TOKEN=$(curl -X PUT -s "http://169.254.169.254/latest/api/token" -H "X-aws-ec2-metadata-token-ttl-seconds: 21600") >> /dev/null
# Read multiple variables from multiline output provided by jq
{ read -r AWS_KEY_ID; read -r AWS_SECRET_KEY; read -r AWS_TOKEN;} < <(curl -H "X-aws-ec2-metadata-token: $TOKEN" -s http://169.254.169.254/latest/meta-data/iam/security-credentials/wbg-imagebuilder-role | jq -r '.AccessKeyId , .SecretAccessKey, .Token')

if [ -z "$AWS_KEY_ID" ] || [ -z "$AWS_SECRET_KEY" ] || [ -z "$AWS_TOKEN" ]
then
  echo "##vso[task.logissue type=error]Failed to parse metadata query: one of AWS_KEY_ID, AWS_SECRET_KEY or AWS_TOKEN is empty" >&2
  exit 1
fi



# Replace the values in the aws.toml file
sed -i "s|^accessKeyID = .*|accessKeyID = \"$AWS_KEY_ID\"|" aws.toml
sed -i "s|^secretAccessKey = .*|secretAccessKey = \"$AWS_SECRET_KEY\"|" aws.toml
sed -i "s|^sessionToken = .*|sessionToken = \"$AWS_TOKEN\"|" aws.toml
sed -i "s|^key = .*|key = \"$VMNAME\"|" aws.toml