#!/bin/bash
set -e
# Debug mode is disabled as it's interactive
# set -x


OIS_REST="https://w0lxptenable01.worldbank.org/rest"
Time_Stamp=$(date +%Y%m%d_%H%M)
HEADER2="Content-Type: application/json"
# Define before the trap
TEMPDIR=$(mktemp -d)
RETRY_COUNT=150
DELAY_TIME=60

function CLEANUP {
  # Copy the csv report if we want to save it as artefact
  if [ -n "$ARTEFACT_DIR" ] && [ -d "$ARTEFACT_DIR" ] && [ -n "$REPORT" ]
  then
      cp -a "${REPORT}" "$ARTEFACT_DIR"
  fi

  rm -rf "$TEMPDIR"
}

# Delete the temp dir on exit or Ctrl + C
trap CLEANUP EXIT INT

function _trap_DEBUG() {
    echo "# $BASH_COMMAND";
    while read -r -e -p "debug> " _command; do
        if [ -n "$_command" ]; then
            eval "$_command";
        else
            break;
        fi;
    done
}

# Enable trapping only if debug is enabled
if [[ "$-" == *x* ]]; then
  trap '_trap_DEBUG' DEBUG
fi


while getopts "hc:i:o:a:s:" option; do
  case $option in
    h) echo "usage: $0 -i <IP or FQDN> -o <UNIX || Windows > -a <API ACCESSKEY> -s <API SECRETKEY> [-c ARTEFACT_DIR] "
       exit ;;
    c) if [ -d "$OPTARG" ]
       then
           export ARTEFACT_DIR=$OPTARG
       else
           echo "##vso[task.logissue type=error]$OPTARG is not a directory" >&2
           exit 1
       fi ;;
    i) TARGET=$OPTARG ;;
    o) OS=$OPTARG ;;
    a) ACCESSKEY=$(echo -n "$OPTARG" | base64 --decode) ;;
    s) SECRETKEY=$(echo -n "$OPTARG" | base64 --decode) ;;
    *) echo "Invalid Option detected $option"; exit 1 ;;
  esac
done

# We can define it only after we define the ACCESSKEY and SECRETKEY variables
HEADER1="x-apikey: accesskey=${ACCESSKEY}; secretkey=${SECRETKEY}"

: "${TARGET:?"TARGET IP/FQDN is mandatory, specify with '-i'"}"
: "${OS:?"OS TYPE is mandatory, specify with '-o'"}"
: "${ACCESSKEY:?"API ACCESSKEY is mandatory, specify with '-a'"}"
: "${SECRETKEY:?"API SECRETKEY is mandatory, specify with '-s'"}"

function GET_SCAN_ID {
        CURLRESULT=$(curl -k -H "${HEADER1}" -H "${HEADER2}" ${OIS_REST}/scan?editable%26fields=description,id,name,type,zone,status,ipList,assets)
        CURLRESPONSE=$(echo "$CURLRESULT" | jq -r '.response')
        if [ -z "$CURLRESPONSE" ]
        then
            CURLERROR=$(echo "$CURLRESULT" | jq -r '.error_msg')
            if [ -z "$CURLERROR" ]
            then
                ERROR="$CURLRESULT"
                echo "##vso[task.logissue type=error]ERROR: $ERROR" >&2
                exit 1
            else
                ERROR=$(echo "$CURLRESULT" | jq -r '.error_msg')
                echo "##vso[task.logissue type=error]ERROR: $ERROR" >&2
                exit 1
            fi
        else
            if ! SCAN_ID=$(echo "$CURLRESULT" | jq -r '.response.usable[] | select(.name == "API_UNIX_Scan") | .id')
            then
                echo "##vso[task.logissue type=error]Problem in finding the active scan ID" >&2
                exit 1
            fi
        fi
        # Check if the result is a positive digit
        if [[ "$SCAN_ID" == +([[:digit:]]) ]]
        then
            echo "$SCAN_ID"
        else
            echo "##vso[task.logissue type=error]Our SCAN ID is not a positive number ($SCAN_ID)" >&2
            exit 1
        fi
}

function UPDATE_TARGET_IP {
        local scanid=$1
        local apiip
        if ! apiip=$(curl -s -k -X PATCH -H "${HEADER1}" -H "${HEADER2}" -d '{"ipList": "'"${TARGET}"'"}' "${OIS_REST}/scan/${scanid}" | jq -r '.response.ipList')
        then
            echo "##vso[task.logissue type=error]Problem in updating to the new target IP" >&2
            exit 1
        fi
        if [ "${apiip}" != "${TARGET}" ]
        then
            echo "##vso[task.logissue type=error]Failed to update the scan target IP, exiting now" >&2
            exit 1
        fi

}

function RUN_REPORT_ID {
        local scanid="$1"
        local report_id
        if ! report_id=$(curl -s -k -X POST -H "${HEADER1}" -H "${HEADER2}" ${OIS_REST}/scan/"${scanid}"/launch | jq -r .response.scanResult.id)
        then
            echo "##vso[task.logissue type=error]Problem in lauching scan" >&2
            exit 1
        fi
        if [[ "$report_id" == +([[:digit:]]) ]]
        then
            echo "$report_id"
        else
            echo "##vso[task.logissue type=error]Our Report ID is not a positive number" >&2
            exit 1
        fi
}

function CHK_SCAN_STAT {
        local percentage=20
        local report_id="$1"
        local scan_status="Running"
        local import_status="No Results"
        echo "[$(date +%H:%M:%S)] Scan status {${scan_status}}, Import status {${import_status}}"
        until [ "$scan_status" == "Completed" ] && [ "$import_status" == "Finished" ]
        do
            echo "##vso[task.setprogress value=${percentage};]"
            sleep 30
            api_output=$(curl -s -k -H "${HEADER1}" -H "${HEADER2}" ${OIS_REST}/scanResult?fields=name,description,status,finishTime,importStatus )
            scan_status=$( echo "$api_output" | jq -r --arg ID "${report_id}" '.response.manageable | to_entries[] | select(.value.id == $ID) | .value.status' )
            import_status=$( echo "$api_output" | jq -r --arg ID "${report_id}" '.response.manageable | to_entries[] | select(.value.id == $ID) | .value.importStatus' )
            echo "[$(date +%H:%M:%S)] Scan status {${scan_status}}, Import status {${import_status}}"

            if [ "$percentage" -lt 50 ]
            then
                 add=5
            elif [ "$percentage" -lt 75 ]
            then
                 add=3
            else
                add=1
            fi
            percentage=$((percentage + add))
        done
        export PROGRESS="$percentage"
}

function DOWNLOAD_RPT {
        local reportid="$1"
        # Filter the results that contain the SCAN ID in the Description field and is type csv
        if ! CSV_ID=$(curl -s -k -X GET -H "${HEADER1}" -H "${HEADER2}" ${OIS_REST}/report? | jq -r --arg scanid "Scan Result ID: ${reportid}" '.response.usable | to_entries[] | select((.value.type == "csv") and (.value.description | contains ($scanid)) ) | .value.id')
        then
            echo "##vso[task.logissue type=error]Problem in retrieving the csv report ID" >&2
            exit 1
        elif [[ "$CSV_ID" == +([[:digit:]]) ]]
        then
            if ! curl -s -k -X POST -H "${HEADER1}" -H "${HEADER2}" ${OIS_REST}/report/"${CSV_ID}"/download -o "${TEMPDIR}/${TARGET}_${OS}_TIME${Time_Stamp}.csv"
            then
                echo "##vso[task.logissue type=error]Problem in downloading the csv report locally: $(curl -k -X POST -H "${HEADER1}" -H "${HEADER2}" ${OIS_REST}/report/"${CSV_ID}"/download -o "${TEMPDIR}/${TARGET}_${OS}_TIME${Time_Stamp}.csv" 2>&1)" >&2
                exit 1
            else
                sleep 3
                echo "${TEMPDIR}/${TARGET}_${OS}_TIME${Time_Stamp}.csv"
            fi
        fi
}

function List_Vulnerabilities {
        local report_file="$1"

        if  grep -qiE 'Valid Credentials Provided|Credentialed checks : yes' "$report_file"
        then
            echo "Nessus scanned successfully with the provided credentials"
        else
                echo "##vso[task.logissue type=error]Nessus failed to authenticate with $TARGET" >&2
                scanning_ip=$(awk -F ': ' '/Scanner IP/ {print $2}' "$report_file")
                echo "Check if $scanning_ip is allowed in the Blueprint" >&2
                exit 1
        fi

        # For some reason grep -c is exiting the whole script
        # shellcheck disable=SC2126
        VULN_COUNT=$(grep -E '"Medium"|"High"|"Critical"' "$report_file" | wc -l)
        if [ "$VULN_COUNT" -gt 0 ]
        then
            echo "##vso[task.logissue type=error]We have detected $VULN_COUNT vulnerabilities in $report_file" >&2
            echo "##vso[task.logissue type=error]NESSUS REPORT:" >&2
            cat "$report_file" >&2
            exit 1
        else
            echo "No Medium, High or Critical vulnerabilities found"
        fi

}



### MAIN ###

        echo
        echo TARGET HOST is "${TARGET}"
        echo TARGET OS is "${OS}"
        echo Preparing scan on "${TARGET}" at "${Time_Stamp}"
        echo
        echo "##vso[task.setprogress value=5;]"
        echo "Collecting available scans"
        SCAN_ID=$(GET_SCAN_ID)
        echo "[$(date +%H:%M:%S)] Scan ${SCAN_ID} selected"
        echo "##vso[task.setprogress value=10;]"
        echo "[$(date +%H:%M:%S)] Updating target ip"
        UPDATE_TARGET_IP "$SCAN_ID"
        echo "##vso[task.setprogress value=15;]"
        echo "[$(date +%H:%M:%S)] Launching scan for ${TARGET} using scan ${SCAN_ID}"
        RPT_ID=$(RUN_REPORT_ID "$SCAN_ID")
        echo "[$(date +%H:%M:%S)] Scan launched. The report id is: ${RPT_ID}"
        CHK_SCAN_STAT "$RPT_ID"
        echo "##vso[task.setprogress value=$((PROGRESS + 5));]"
        
        echo "[$(date +%H:%M:%S)] Scan completed. ${DELAY_TIME} seconds waiting for Nessus to generate report."
        echo "[$(date +%H:%M:%S)] Maximum retries set to ${RETRY_COUNT}"
        sleep $DELAY_TIME
        echo "[$(date +%H:%M:%S)] Trying to download report to ${TEMPDIR}/${TARGET}_${OS}_TIME${Time_Stamp}.csv"
        REPORT=$(DOWNLOAD_RPT "$RPT_ID")
        echo "URL :- " $DOWNLOAD_RPT
        echo "Rpt ID :- " $RPT_ID
        attempt=1
        completed=false
        until [ "$completed" = true ] || [ "$attempt" -ge $RETRY_COUNT ];
        do
            echo "[$(date +%H:%M:%S)] Report download #${attempt} failed. Retrying in ${DELAY_TIME} seconds..."
            sleep $DELAY_TIME
            attempt=$((attempt + 1))
            REPORT=$(DOWNLOAD_RPT "$RPT_ID")
            if [[ -n "$REPORT" ]]; 
            then
                echo "[$(date +%H:%M:%S)] Report download successful: $REPORT"
                if [ "$(jq '.response' "$REPORT" 2>/dev/null)" = "\"Report is processing.\"" ]; 
                then
                    echo "[$(date +%H:%M:%S)] The report is still processing."
                else
                    echo "[$(date +%H:%M:%S)] The report is completed."
                    completed=true
                fi
            fi
        done
        if [ "$completed" != true ]; 
        then
            echo "[$(date +%H:%M:%S)] ${RETRY_COUNT} retry attempts failed."
            exit 1
        fi
        # Needed for the cleanup function
        export REPORT
        echo "##vso[task.setprogress value=$((PROGRESS + 10));]"
        List_Vulnerabilities "$REPORT"
        echo "##vso[task.setprogress value=100;]"
