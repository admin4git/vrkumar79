connect-AzAccount -Identity -AccountId 4bf4b147-128d-41ef-9259-baae5335841a #wbgimagebuilder
select-AzSubscription -SubscriptionId "7b4d1501-6351-4d0f-a681-0473c2221a05" #WBG AZ ITSSM Prod Admin

$location = "East US"
$resourceGroup = 'WBG-OS-Image'
$GalleryImageDefinitionName = "VMSS-Preconfigured-Windows2019"

$versions = Get-AzGalleryImageVersion -ResourceGroupName $resourceGroup -GalleryName SecurityAccreditedGoldImages -GalleryImageDefinitionName $GalleryImageDefinitionName
$lastversion = ""
if($null -eq $versions)
{
	$lastversion = "1900.01.1"
} else
{
	$lastversion = $versions.Name | Select-Object -Last 1
}
$lastversarr = $lastversion.Split(".")
$date = Get-Date
$monthstring = ""

if($date.Month -lt 10)
{
	$monthstring = "0$($date.Month)"
} else
{
	$monthstring = "$($date.Month)"
}
$versionstring = "$($date.Year).$($monthstring).01"

if($date.Year -eq $lastversarr[0])
{
	if($monthstring -eq $lastversarr[1])
	{
		$nextversionnumber = [int]$lastversarr[2]+1
		if($nextversionnumber -lt 10)
		{
			$nextversionnumber = "0$($nextversionnumber)"
		}
		$versionstring = "$($date.Year).$($monthstring).$($nextversionnumber)"
	}
}
#$versionstring

$variablejson = get-content "$($env:VariablePath)" -Raw
$variableobj = ConvertFrom-Json $variablejson

Write-Output "Adding new Image version '$versionstring' to the '$GalleryImageDefinitionName'..."
New-AzGalleryImageVersion -ResourceGroupName $resourceGroup -GalleryName SecurityAccreditedGoldImages -GalleryImageDefinitionName $GalleryImageDefinitionName -Location $location -Name $versionstring -SourceImageId $variableobj.ImageID
