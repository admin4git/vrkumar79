#provider "azurerm" {
#  features {}
#  subscription_id            = "" # CHANGE !!!
#  tenant_id                  = "31a2fec0-266b-4c67-b56e-2796d8f59c36"
#  use_msi                    = true
#  skip_provider_registration = true # Needed as sometimes Azure doesn't register properly the providers
#}

#provider "azurerm" {
#
#  alias = "gallery-sub"
#  features {}
#  subscription_id            = "7b4d1501-6351-4d0f-a681-0473c2221a05"
#  tenant_id                  = "31a2fec0-266b-4c67-b56e-2796d8f59c36"
#  use_msi                    = true
#  skip_provider_registration = true
#}
