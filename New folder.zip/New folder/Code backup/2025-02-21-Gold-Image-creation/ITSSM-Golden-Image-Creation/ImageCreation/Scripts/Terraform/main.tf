# provider.tf
terraform {
required_providers {
    azurerm = {
    source  = "hashicorp/azurerm"
    version = ">=3.69.0"
    }
}
cloud {
    organization = "WorldBank"
    hostname     = "app.terraform.io"
    workspaces {
    name    = "ITSSM-GoldImage-RHEL999999999999" # CHANGE !!!
    #project = "Default Project" # CHANGE !!!
    }
}
}
provider "azurerm" {
features {}
#LAB 64c555a9-193a-4e08-af9d-daaa32034faa
#Admin "7b4d1501-6351-4d0f-a681-0473c2221a05"
subscription_id            = "7b4d1501-6351-4d0f-a681-0473c2221a05"  # CHANGE !!!
tenant_id                  = "31a2fec0-266b-4c67-b56e-2796d8f59c36"
use_msi                    = true
skip_provider_registration = true # Needed as sometimes Azure doesn't register properly the providers
}

# Enable only if you receive an error about "Microsoft.Compute" provider is not registered
# resource "azurerm_resource_provider_registration" "enable_VM_creation" {
#   name = "Microsoft.Compute"
# }

provider "azurerm" {
alias = "gallery-sub"
features {}
subscription_id            = "7b4d1501-6351-4d0f-a681-0473c2221a05"
tenant_id                  = "31a2fec0-266b-4c67-b56e-2796d8f59c36"
use_msi                    = true
skip_provider_registration = true
}

/* # resourcegroup.tf
resource "azurerm_resource_group" "rg" {
name     = local.VM_ResourceGroupName
location = "East US"
tags = merge(
    tomap({
    MissionCritical         = local.TAG_MissionCritical ### Recommended to have
    Description             = local.TAG_Description     ### Recommended to have
    Client_Unit             = local.TAG_ClientUnit      ### Recommended to have
    ENV                     = local.VM_Environment      ### Recommended to have
    Security_Classification = local.TAG_MissionCritical ### Recommended to have
    Leap                    = local.Leap                ### Mandatory
}), local.tags)
} */

#locals.tf
locals {
tags = {
    "Project"                 = "Golden Image",
    "Stage"                   = "prod",
    "Managed_By"              = local.TAG_ClientUnit
    "Purpose"                 = "Final testing for golden image"
    "Deplyedby_WorkspaceName" = terraform.workspace
}
VM_Location = "eastus"
# Deploy VMs only to subscriptions that have the env specified here
# For example , use 'lab' for 'WBG AZ ITSSM Lab' subscription
VM_Environment              = "prod"
VM_ResourceGroupName        = "WBG-OS-Image" #"wbg-os-image"
#Admin
#VM_VirtualNetworkName       = "wbgadmin-prod-pdmz-vnet"
#VM_VirtualNetworkRGName     = "networking-RG"
#VM_VirtualNetworkSubnetName = "misc"
#Lab
#VM_VirtualNetworkName       = "smlabcdc1"
#VM_VirtualNetworkRGName     = "SMLab-Networking"
VM_VirtualNetworkName       = "wbgadmin-prod-pdmz-vnet"
VM_VirtualNetworkRGName     = "networking-RG"
VM_VirtualNetworkSubnetName = "misc"
VM_HostName                 = "gldtest"
VM_HostSize                 = "Standard_B2s"
#VM_ExistingHostGroups       = [ "hg-existing-host-group1", "hg-existing-host-group2" ] # Optional
TAG_MissionCritical         = "No"
TAG_AppType                 = "MISC"
TAG_Description             = "Final testing for golden image"
TAG_ClientUnit              = "ITSSM"
TAG_SecurityClassification  = "Non-Critical"
Leap                        = "wbg-azure" ### Mandatory !!!!
# if not defined - first vm is in zone "1", next one "2" , next in "3" and repeat
# If you need to control the zone for each VM (created by the count meta attribute),
# set a zone for each VM.This example sets assigns all three VMs to zone 3
#VM_Zone = ["3", "3", "3"]
# Lun IDs are dynamic and are based of the order of disks in this var
# Valid options for the storage_account_type:
# Standard_LRS, StandardSSD_ZRS, Premium_LRS, PremiumV2_LRS, Premium_ZRS, StandardSSD_LRS or UltraSSD_LRS
/* lunmap = [
    {
    name                 = "datadisk1"
    storage_account_type = "UltraSSD_LRS"
    caching              = "None"
    disk_iops_read_write = 600
    # Settable only when the disk is shared
    # disk_iops_read_only  = 700
    disk_mbps_read_write = 150
    # Settable only when the disk is shared
    # disk_mbps_read_only  = 175
    size_in_gb = 10
    },
    {
    name                 = "datadisk2"
    storage_account_type = "Standard_LRS"
    size_in_gb           = 20
    caching              = "ReadWrite"
    }
] */
}

# vms.tf

/* module "wbg-vm-rhel7" {
source     = "app.terraform.io/WorldBank/wbg-vm-rhel/azurerm"
version    = "2.1.0"
count      = 1 # Number of VMs created by this module
depends_on = [azurerm_resource_group.rg]
providers = {
    azurerm.gallery-sub = azurerm.gallery-sub
}
additional_tags             = local.tags
current_count               = count.index # Needed for proper VM naming
VM_ResourceGroupName        = local.VM_ResourceGroupName
VM_Location                 = local.VM_Location
VM_Environment              = local.VM_Environment
VM_VirtualNetworkName       = local.VM_VirtualNetworkName
VM_VirtualNetworkRGName     = local.VM_VirtualNetworkRGName
VM_VirtualNetworkSubnetName = local.VM_VirtualNetworkSubnetName
# Enable when you want to specifically set each VM's zone
# VM_Zone                    = local.VM_Zone
VM_HostName                = local.VM_HostName
VM_HostSize                = local.VM_HostSize
VM_OSVersion               = 7
VM_ExistingHostGroups      = local.VM_ExistingHostGroups
TAG_Description            = local.TAG_Description
TAG_MissionCritical        = local.TAG_MissionCritical
TAG_AppType                = local.TAG_AppType
TAG_ClientUnit             = local.TAG_ClientUnit
TAG_SecurityClassification = local.TAG_SecurityClassification
lunmap                     = local.lunmap
Leap                       = local.Leap
} */

module "wbg-vm-rhel" {
source = "./terraform-azurerm-wbg-vm-rhel"
count      = 1 # Number of VMs created by this module
#depends_on = [azurerm_resource_group.rg]
providers = {
    azurerm.gallery-sub = azurerm.gallery-sub
}
additional_tags             = local.tags
current_count               = count.index # Needed for proper VM naming
VM_ResourceGroupName        = local.VM_ResourceGroupName
VM_Location                 = local.VM_Location
VM_Environment              = local.VM_Environment
VM_VirtualNetworkName       = local.VM_VirtualNetworkName
VM_VirtualNetworkRGName     = local.VM_VirtualNetworkRGName
VM_VirtualNetworkSubnetName = local.VM_VirtualNetworkSubnetName
# Enable when you want to specifically set each VM's zone
# VM_Zone                    = local.VM_Zone
VM_HostName                = local.VM_HostName
VM_HostSize                = local.VM_HostSize
VM_OSVersion               = 999999999999
TAG_Description            = local.TAG_Description
TAG_MissionCritical        = local.TAG_MissionCritical
TAG_AppType                = local.TAG_AppType
TAG_ClientUnit             = local.TAG_ClientUnit
TAG_SecurityClassification = local.TAG_SecurityClassification
#lunmap                     = local.lunmap
Leap                       = local.Leap
# Set VM Name override, as the automatic Naming discovery doesn't work with more than one module definition
#vmname_override            = "rhel8test"
}
