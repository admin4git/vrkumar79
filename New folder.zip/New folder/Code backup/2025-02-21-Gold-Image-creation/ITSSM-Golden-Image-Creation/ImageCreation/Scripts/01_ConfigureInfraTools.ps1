function Invoke-BlobItems
{
    param (
        [Parameter(Mandatory)]
        [string]$URL,
        [string]$WorkPath = (Get-Location)
    )
    $uri = $URL.split('?')[0]
    $sas = $URL.split('?')[1]
 
    $newurl = $uri + "?restype=container&comp=list&" + $sas 
    #Invoke REST API
    $body = Invoke-RestMethod -uri $newurl
 
    #cleanup answer and convert body to XML
    $xml = [xml]$body.Substring($body.IndexOf('<'))
 
    #use only the relative Path from the returned objects
    $files = $xml.ChildNodes.Blobs.Blob.Name
 
    #create folder structure and download files
    $retrycount = 5
    $files | ForEach-Object { 
        Write-Output "Downloading $_ ... to $WorkPath "; 
        New-Item (Join-Path $WorkPath (Split-Path $_)) -ItemType Directory -ea SilentlyContinue | Out-Null
        $retry = 0;
        $success = $false
        while (!$success -and $retry -lt $retrycount) 
        {
            try 
            {
                $retry++
                (New-Object System.Net.WebClient).DownloadFile($uri + "/" + $_ + "?" + $sas, (Join-Path $WorkPath $_))
                $success = $true
            }
            catch 
            {
                $ex = $_.Exception
                while ($null -ne $ex)
                {
                    Write-Output "[TRY #$($retry)] $($ex.Message)"
                    $ex = $ex.InnerException;
                }
                Start-Sleep -Seconds 5
            }
        }
        if ($retry -ge $retrycount)
        {
            throw "Failed to download $_"
        }
    }
}
 
Write-Output "Checking package updates..."
$repocheck = $(sudo yum check-update) 2>&1
$statuscheck = $(sudo subscription-manager list | grep "Status:") 
$basecheck = $(sudo subscription-manager config | grep "baseurl")
$containserror = $repocheck | Where-Object { $_.ToString().Contains("Failed to download metadata for repo") -or $_.ToString().Contains("system is not registered") }
if ($null -ne $containserror -or (![string]::IsNullOrWhiteSpace($statuscheck) -and $statuscheck.Contains("Not Subscribed")) -or (![string]::IsNullOrWhiteSpace($basecheck) -and $basecheck.Contains("worldbank.org")))
{
    $username = ""
    $password = ""
    $EncodedSecret = $($env:username)
    if (![string]::IsNullOrWhiteSpace($EncodedSecret))
    {
        $username = [System.Text.Encoding]::Unicode.GetString([System.Convert]::FromBase64String($EncodedSecret))
    }
    $EncodedSecret = $($env:password)
    if (![string]::IsNullOrWhiteSpace($EncodedSecret))
    {
        $password = [System.Text.Encoding]::Unicode.GetString([System.Convert]::FromBase64String($EncodedSecret))
    }
    sudo chattr -i /etc/yum.repos.d/
    sudo chattr -i /etc/rhsm/rhsm.conf
    sudo chattr -i -R /etc/rhsm/ca/
    sudo chattr -i -R /etc/pki/product
    sudo chattr -i -R /etc/pki/entitlement
    sudo chattr -i -R /etc/pki/consumer
    sudo chattr -i /etc/yum.repos.d/redhat.repo
    sudo chattr -i /etc/pki/product-default
    sudo subscription-manager unregister
    sudo subscription-manager clean
    sed 's/katello-server-ca/redhat-uep/g' -i /etc/rhsm/rhsm.conf
 
    $tries = 0
    $success = $false
    while ($tries -lt 10 -and !$success) 
    {
        $tries++
        Write-Output "Trying to connect redhat... #$($tries)"
        $reg = $(sudo subscription-manager register --serverurl 'https://subscription.rhsm.redhat.com:443/subscription' --baseurl 'https://cdn.redhat.com' --force --username "$username" --password "$password") 2>&1
        $reg
        if ($null -ne ($reg | Where-Object { $_.ToString().Contains("The system has been registered") -or $_.ToString().Contains("The registered system name is") } ))
        {
            $success = $true
        }
        else 
        {
            Write-Output "Waiting to retry..."
            $countdown = 30
            for ($i = 0; $i -lt $countdown; $i++) 
            {
                $percentage = ([Math]::Round($($i / $countdown * 100)))
                Write-Output "##vso[task.setprogress value=$percentage;]"
                Start-Sleep -Seconds 1
            }
        }
    }
    if (!$success)
    {
        throw "Failed to reach RedHat CDN after $tries tries"
    }
 
    $null = $(sudo subscription-manager repos --disable rhel-7-server-rpms) 2>&1
 
    
    $majorver = $(Get-Content /etc/redhat-release | tr -dc 0-9 | head -c 1)
    Invoke-WebRequest -sSL Tls13 -Uri https://packages.microsoft.com/config/rhel/$majorver/packages-microsoft-prod.rpm -OutFile packages-microsoft-prod.rpm
    sudo yum reinstall packages-microsoft-prod.rpm -y
    Remove-Item packages-microsoft-prod.rpm -Force
    sudo chattr +i /etc/yum.repos.d/redhat.repo
    sudo chattr +i /etc/rhsm/rhsm.conf
    sudo chattr +i -R /etc/rhsm/ca/
    sudo chattr +i -R /etc/pki/product/
    sudo chattr +i -R /etc/pki/entitlement
    sudo chattr +i -R /etc/pki/consumer/
    sudo chattr +i /etc/rhsm/rhsm.conf
    sudo chattr +i /etc/yum.repos.d/redhat.repo
    sudo chattr +i /etc/pki/product-default
}
 
$EncodedSecret = $($env:infratoken)
$token = ""
if (![string]::IsNullOrWhiteSpace($EncodedSecret))
{
    $token = [System.Text.Encoding]::Unicode.GetString([System.Convert]::FromBase64String($EncodedSecret))
}
 
$collectionurl = $($env:collectionurl)
$projectname = $($env:projectname)
$buildid = $($env:buildid)
$buildurl = "$($collectionurl)$($projectname)/_build/results?buildId=$($buildid)&view=results"
 
try
{
    $timeout = 600 # Timeout in seconds (10 minutes)
    $elapsed = 0
    $interval = 5 # Check interval in seconds
 
    while (($locksExist = Test-Path "/Data/.dirlock*") -or ($svlocksExist = Test-Path "/Data/.svlock*") -and $elapsed -lt $timeout)
    {
        if ($svlocksExist)
        {
            Write-Output "Service is currently busy, waiting for finish..."
        }
        else 
        {
            Write-Output "Working directory is locked, waiting for release..."
        }
        Start-Sleep -Seconds $interval
        $elapsed += $interval
    }
 
    if ($elapsed -ge $timeout)
    {
        throw "Timeout waiting for lock files to be released."
    }
 
    # Optionally, force remove lock files if they still exist
    if (Test-Path "/Data/.dirlock*")
    {
        Remove-Item "/Data/.dirlock*" -Force -ErrorAction SilentlyContinue
    }
    if (Test-Path "/Data/.svlock*")
    {
        Remove-Item "/Data/.svlock*" -Force -ErrorAction SilentlyContinue
    }
 
    $rnd = Get-Random -Maximum 100000
    "Pipeline ($buildurl) is currently using this directory" | Set-Content "/Data/.dirlock$($rnd)"
    bash -c 'sudo rm -rf /Data/REPO/'
    mkdir /Data/REPO/
    Write-Output "Downloading Infra files"
    Set-Location /Data/REPO
    Invoke-BlobItems -URL $token
 
    Write-Output "Setting up local repository"
    sudo createrepo .
    Set-Location ..
    sudo chown _osbuild-composer: REPO -R
 
    Write-Output "Stopping osbuilder services"
    bash -c 'sudo systemctl stop osbuild\*'
    bash -c 'sudo systemctl reset-failed osbuild\*'
 
    Write-Output "Deleting temporary folders and files"
    bash -c 'sudo rm -rf /var/cache/osbuild-worker/*'
    bash -c 'sudo rm -rf /var/cache/osbuild-composer/*'
    bash -c 'sudo rm -rf /var/lib/osbuild-composer/artifacts/*'
 
    Write-Output "Starting osbuilder services"
    bash -c 'sudo systemctl start osbuild-composer.socket'
    bash -c 'sudo systemctl restart osbuild-composer.service'
}
catch
{
    throw $_
}
finally
{
    Remove-Item "/Data/.dirlock$($rnd)" -Force -ErrorAction SilentlyContinue
}