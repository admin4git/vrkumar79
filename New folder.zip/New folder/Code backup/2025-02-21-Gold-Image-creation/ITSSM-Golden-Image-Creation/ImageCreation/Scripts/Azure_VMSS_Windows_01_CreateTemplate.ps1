connect-AzAccount -Identity -AccountId 4bf4b147-128d-41ef-9259-baae5335841a #wbgimagebuilder
select-AzSubscription -SubscriptionId "50be6bf8-5539-448d-9940-4d5ff24b6c42" #WBG AZ ITSSM Prod Automation

$resourceGroup = 'Imagebuilding'
$templateName = "VMSSWindows2019"
$templateFile = "vmss-windows2019.json"
$destinationName = "WBG-OS-Image"

$existingTemplate = Get-AzImageBuilderTemplate -Name $templateName -ResourceGroupName $resourceGroup -ErrorAction SilentlyContinue
if($null -ne $existingTemplate)
{
	"Removing old template..."
    Remove-AzImageBuilderTemplate -Name $templateName -ResourceGroupName $resourceGroup
}

$date = Get-Date
$monthstring = ""
$daystring = ""
$hourstring = ""
$minutestring = ""

if($date.Month -lt 10)
{
	$monthstring = "0$($date.Month)"
} else
{
	$monthstring = "$($date.Month)"
}
if($date.Day -lt 10)
{
	$daystring = "0$($date.Day)"
} else
{
	$daystring = "$($date.Day)"
}
if($date.Hour -lt 10)
{
	$hourstring = "0$($date.Hour)"
} else
{
	$hourstring = "$($date.Hour)"
}
if($date.Minute -lt 10)
{
	$minutestring = "0$($date.Minute)"
} else
{
	$minutestring = "$($date.Minute)"
}

$ImageName = "VMSS-Windows2019-image-$($date.Year)$($monthstring)$($daystring)$($hourstring)$($minutestring)-eastus"
$existingimage = Get-AzImage -Name $ImageName
if($null -ne $existingimage)
{
	"Removing old image..."
    Remove-AzImage -ResourceGroupName $existingimage.ResourceGroupName -ImageName $existingimage.Name -Force
}

$template = Get-Content $templateFile -Raw
$template = $template.Replace("¤vmname¤", $ImageName)
$template | Set-Content $templateFile

"Creating new template with name $templateName"
New-AzImageBuilderTemplate -Name $templateName -ResourceGroupName $resourceGroup -JsonTemplatePath $templateFile
"Starting to build new VM image with name $ImageName"
Start-AzImageBuilderTemplate -Name $templateName -ResourceGroupName $resourceGroup -ErrorAction SilentlyContinue -AsJob
Start-Sleep -Seconds 30
$imagetemplate = Get-AzImageBuilderTemplate -Name $templateName -ResourceGroupName $resourceGroup

while ($imagetemplate.LastRunStatusRunState -eq "Running")
{
	"Image building is still running"
	if($([Environment]::GetEnvironmentVariable('SYSTEM_DEBUG')))
	{
		"LastRunStatusEndTime: $($imagetemplate.LastRunStatusEndTime)"
		"LastRunStatusRunState: $($imagetemplate.LastRunStatusRunState)"
		"LastRunStatusRunSubState: $($imagetemplate.LastRunStatusRunSubState)"
		"ProvisioningState: $($imagetemplate.ProvisioningState)"
	}
	Start-Sleep -Seconds 300
	$imagetemplate = Get-AzImageBuilderTemplate -Name $templateName -ResourceGroupName $resourceGroup
}
if($([Environment]::GetEnvironmentVariable('SYSTEM_DEBUG')))
{
	$imagetemplate | Select-Object *
}

if($imagetemplate.LastRunStatusRunState -eq "Succeeded")
{
	"Image build completed."
	Start-Sleep -Seconds 5
	$image = get-azimage -Name $ImageName
	$image
	"Moving image to the admin subscription..."
	$resourcesToMove = @($image.Name)
	$resource = Get-AzResource -ResourceGroupName $resourceGroup | Where-Object { $_.Name -in $resourcesToMove }
	Move-AzResource -ResourceId $resource.ResourceId -DestinationResourceGroupName $destinationName -DestinationSubscriptionId "7b4d1501-6351-4d0f-a681-0473c2221a05" -Force
	"Move completed"

	$image.id = $image.id.Replace("50be6bf8-5539-448d-9940-4d5ff24b6c42","7b4d1501-6351-4d0f-a681-0473c2221a05")
	$image.id = $image.id.Replace("IMAGEBUILDING","WBG-OS-Image")
	Write-Host "##vso[task.setvariable variable=IMAGE_ID;issecret=false;isOutput=true]$($image.Id)"

	$obj = New-Object psobject
	$obj | Add-Member ImageID $image.Id
	$transporter = $obj | ConvertTo-Json
	$transporter | Set-Content variable.json
}
else
{
	throw "Image build status is ($($imagetemplate.LastRunStatusRunState))"
}
