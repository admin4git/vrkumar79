#!/bin/bash
echo "Checking and waiting for image build to complete..."

# jq check
if ! command -v jq &> /dev/null; then
    echo "Error: jq is not installed"
    # shellcheck disable=SC2154
    rm -rf "$svlockvar"
    exit 1
fi

# Check the $COMPSER_BUILDID variable
if [ -z "$COMPSER_BUILDID" ]; then
    echo "Error: COMPSER_BUILDID variable is not set"
    rm -rf "$svlockvar"
    exit 1
fi

sleep 10
STATUS="RUNNING"
until [  "$STATUS" != "RUNNING" ] && [ "$STATUS" != "WAITING" ];
    do
      sleep 30
      STATUS=$(composer-cli compose info "$COMPSER_BUILDID" -j | jq -r '.[].body.queue_status')
      echo "$STATUS"

done

rm -rf "$svlockvar"
COMPOSER_RESULT="$(composer-cli compose info "$COMPSER_BUILDID" -j | jq -r '.[].body.queue_status')"
echo "$COMPOSER_RESULT"
if [ "$COMPOSER_RESULT" != "FINISHED" ]
then
    composer-cli compose log "$COMPSER_BUILDID"
    journalctl --no-pager --boot | grep -i osbuild-worker
    echo "##vso[task.logissue type=error]Composer finished with $COMPOSER_RESULT. BuildID is: $COMPSER_BUILDID" 1>&2
    exit 2
fi
