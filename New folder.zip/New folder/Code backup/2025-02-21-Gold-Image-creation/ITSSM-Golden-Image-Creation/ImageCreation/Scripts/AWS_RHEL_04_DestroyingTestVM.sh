#!/bin/bash

echo "Removing composed osbuild image ${COMPSER_BUILDID}..."
composer-cli compose delete "$COMPSER_BUILDID" -j | jq -r '""'

if [ -z "$INSTANCE_ID" ]; then
  echo "INSTANCE_IDS is empty"
else
  if aws ec2 describe-instances --instance-ids "${INSTANCE_ID}" 2>&1 | grep -q 'InvalidInstanceID.NotFound'; then
    echo "Instance ${INSTANCE_ID} not found"
  else
    aws ec2 terminate-instances --instance-ids "${INSTANCE_ID}"
    echo "Instance ${INSTANCE_ID} terminated"
  fi
fi

echo "##vso[task.setvariable variable=IMAGE_ID;issecret=false;isOutput=true]$IMAGE_ID"
