foreach ($file in $(get-childitem -Exclude *.sh,*.ps1,Terraform))
{
    Write-Output "Processing file '$file...'"
    $toml = Get-Content $file -Raw
    $tomlarray = $toml.Split("¤")
    $i = 0; 
    foreach ($keychar in $tomlarray) 
    { 
        $i++; 
        if($i % 2 -eq 0) 
        { 
            Write-Output "Writing secret for $keychar into $file..."
            $EncodedSecret = [System.Environment]::GetEnvironmentVariable($keychar)
            #Write-Output "Received secret: $EncodedSecret"
            if(![string]::IsNullOrWhiteSpace($EncodedSecret))
            {
                $secret = [System.Text.Encoding]::Unicode.GetString([System.Convert]::FromBase64String($EncodedSecret))
                $toml = $toml.Replace("¤$keychar¤", $secret)
            }
        }
    }
    $toml | Set-Content $file
}

$VENDOR_TAG=Get-Content /sys/devices/virtual/dmi/id/sys_vendor
switch ($VENDOR_TAG) 
{
    "Microsoft Corporation" 
    {
        Write-Output "Azure system detected"
        $cloudtag="Z"
        break
    }
    "Amazon EC2" 
    {
        Write-Output "Amazon system detected"
        $cloudtag="A"
        break
    }
    "VMware, Inc." 
    {
        Write-Output "VmWare system detected"
        $cloudtag="0"
        break
    }
    Default 
    {
        $ASSET_TAG=Get-Content /sys/devices/virtual/dmi/id/chassis_asset_tag
        switch ($ASSET_TAG) 
        {
            "7783-7084-3265-9085-8269-3286-77"
            {
                Write-Output "Azure system detected"
                $cloudtag="Z"
                break
            }
            "Amazon EC2"
            {
                Write-Output "Amazon system detected"
                $cloudtag="A"
                break
            }
            "No Asset Tag"
            {
                Write-Output "VmWare system detected"
                $cloudtag="0"
                break
            }
            Default 
            {
                throw "Could not detect cloud provider"
            }
        }
    }
}

$ostag=$($env:OSVersion).Substring($($env:OSVersion).Length-1,1)

$vmsstag=''
if ($($env:VMSS) -eq $true) 
{
    Write-Output "VMSS deployment selected"
    $vmsstag='SS'
}

$VMNAME="W$($cloudtag)LXTGLDR$($ostag)$($vmsstag)01"
$buildername=$($env:buildername)

Write-Output "##vso[task.setvariable variable=VMNAME;issecret=false;isOutput=true]$VMNAME"
Write-Output "##vso[task.setvariable variable=CTAG;issecret=false;isOutput=true]$cloudtag"
Write-Output "##vso[task.setvariable variable=buildername;issecret=false;isOutput=true]$buildername"
