$directory = '.\Terraform'

Set-Location $directory
terraform init
terraform destroy -auto-approve