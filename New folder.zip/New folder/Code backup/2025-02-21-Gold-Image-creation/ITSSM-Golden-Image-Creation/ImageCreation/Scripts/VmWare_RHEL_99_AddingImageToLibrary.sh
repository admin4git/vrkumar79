#!/bin/bash
# shellcheck disable=2154

GOVC_URL=$(echo "$GOVC_URL" | base64 --decode)
export GOVC_URL

#govc library.ls
LIBRARY="/WBG Content Library"
TARGETNAME="$OSVersion-Accredited-image-$(date +%Y%m%d%H%M)"
TEMPLATENAME="$OSVersion-Accredited-image"

echo "Importing image file..."
govc import.vmdk "/Data/govc/$VMNAME.vmdk"
VM=$(govc vm.info "$VMNAME")
if [ -z "$VM" ]
then
    echo "Creating VM ""$VMNAME""..."
    govc vm.create -net.adapter=vmxnet3 -m=4096 -c=2 -g="${OSVersion,,}"_64Guest -firmware=efi -disk="$VMNAME/$VMNAME.vmdk" -disk.controller=scsi -on=false -folder="/DC5/vm/vRARHELGoldenImage" "$VMNAME"
fi

echo "Importing VM into library as $TARGETNAME..."
govc library.clone -ds "$GOVC_DATASTORE" -vm "$VMNAME" "$LIBRARY" "$TARGETNAME"
echo "Removing old ServerNow image ${LIBRARY}/${TEMPLATENAME}..."
govc library.rm "${LIBRARY}/${TEMPLATENAME}"
echo "Adding ServerNow image ${LIBRARY}/${TEMPLATENAME}..."
govc library.clone -ds "$GOVC_DATASTORE" -vm "$VMNAME" "$LIBRARY" "$TEMPLATENAME"
