connect-AzAccount -Identity -AccountId 4bf4b147-128d-41ef-9259-baae5335841a #wbgimagebuilder
select-AzSubscription -SubscriptionId "7b4d1501-6351-4d0f-a681-0473c2221a05" #WBG AZ ITSSM Prod Admin

$keyvaultentries = Get-AzKeyVaultSecret -VaultName 'wbggoldimagecreation'

foreach ($entry in $keyvaultentries)
{
    $entryname = $entry.Name
    $secret = Get-AzKeyVaultSecret -VaultName 'wbggoldimagecreation' -Name $entryname -AsPlainText
    $Bytes = [System.Text.Encoding]::Unicode.GetBytes($secret)
    $EncodedSecret =[Convert]::ToBase64String($Bytes)
    Write-Output "Adding secret to $entryname variable"
    Write-Host "##vso[task.setvariable variable=$entryname;issecret=true;isOutput=true;]$EncodedSecret"
}
