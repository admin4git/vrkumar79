$envid = 0

$rurl = "https://vsrm.dev.azure.com/ITSEN-Collection/$($env:SYSTEM_TEAMPROJECTID)/_apis/Release/releases/$($env:RELEASE_RELEASEID)?api-version=6.1-preview.8"
$releasedata = Invoke-RestMethod -Method Get -Uri $rurl -Headers @{Authorization = "Bearer $env:SYSTEM_ACCESSTOKEN"}
write-Host "----------------------------------"
$env

$trigger = "$($env:RELEASE_TRIGGERINGARTIFACT_ALIAS)"
switch -Wildcard ($trigger)
{
    "_Golden Image - AWS*"
    {
        $envid = ($releasedata.environments | Where-Object { $_.name -eq 'AWS Linux Stage' }).Id
        break
    }
    "_Golden Image - VmWare*"
    {
        $envid = ($releasedata.environments | Where-Object { $_.name -eq 'VmWare Linux Stage' }).Id
        break
    }
    "_Golden Image - Azure*"
    {
        $envid = ($releasedata.environments | Where-Object { $_.name -eq 'Azure Linux Stage' }).Id
        break
    }
    "_VMSS Image Creation - Windows2019 Azure"
    {
        $envid = ($releasedata.environments | Where-Object { $_.name -eq 'Azure VMSS Windows Stage' }).Id
        break
    }
    "_VMSS Image Creation - RHEL9 Azure"
    {
        $envid = ($releasedata.environments | Where-Object { $_.name -eq 'Azure VMSS Linux Stage' }).Id
        break
    }
}
Write-Host "Triggering Artifact: $trigger"
Write-Host "Selected id: $envid"

$body = @"
{
    "status": "inProgress",
    "scheduledDeploymentTime": null,
    "comment": null,
    "variables": {}
}
"@

if($envid -gt 0)
{
    $url = "https://vsrm.dev.azure.com/ITSEN-Collection/$env:SYSTEM_TEAMPROJECTID/_apis/Release/releases/$($env:RELEASE_RELEASEID)/environments/$($envid)?api-version=5.1-preview.6"
    Invoke-RestMethod -Method Patch -Uri $url -Headers @{Authorization = "Bearer $env:SYSTEM_ACCESSTOKEN"} -Body $body -ContentType "application/json"
}
