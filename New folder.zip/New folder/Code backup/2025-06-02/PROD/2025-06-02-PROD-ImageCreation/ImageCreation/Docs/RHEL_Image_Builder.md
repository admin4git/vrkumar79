<div id="top"></div>

<!-- TABLE OF CONTENTS -->
<details>
  <summary>Table of Contents</summary>
  <ol>
    <li>
      <a href="#**project-overview**">Project Overview</a>
      <ul>
        <li><a href="#**goals**">Goals</a></li>
        <li><a href="#**architecture**">Architecture</a></li>
      </ul>
    </li>
        <li>
      <a href="#**usage**">Usage</a>
      <ul>
        <li><a href="#**node-setup**">Node Setup</a></li>
        <li><a href="#**trigger-an-image-build**">Trigger an Image Build</a></li>
        <li><a href="#**troubleshooting**">Troubleshooting<a></li>
        <li><a href="#**support**">Support<a></li>
      </ul>
    </li>
  </ol>
</details>

<!-- Project Overview -->
## **Project Overview**

### **Goals**
  The Image builder process aims to:    

    - Create an image in a manner that is consistent, reliable and independent of the underlying operating system version, previous image builds or the cloud environment.       
    - The whole image build process can be easily followed, audited and reproduced.    
    - All code is version controlled (for auditing purposes, peer review and possible roll-back) and all secrets are stored in a secure manner.    
    - The Image build process distributes the images automatically to all environments after an automatic security validation without any human intervention.    
    - The images are secure to be used even before post-provisioning (Chef).    
    - Ability to expand the image builder with newer architectures (e.x. arm64 ), platforms (BareMetal) and newer major versions of RHEL.     
<p align="right">(<a href="#top">back to top</a>)</p>    

### **Architecture**
- Logical Diagram of the process:    
  ![Diagram](pics/Image_builder-logic.jpg)    
  </br>    
<p align="right">(<a href="#top">back to top</a>)</p>    

- Detailed diagram of the Image Builder platform:    
  ![Diagram](pics/diagram.jpg)    
  </br>    
<p align="right">(<a href="#top">back to top</a>)</p>    

- Explanation of the diagram:    
  1. [Azure](https://dev.azure.com/ITSEN-Collection/Enterprise-Services/_git/ITSSM-Systems-Engineering?path=/ImageCreation/ImageCreation2.0/CI/azure-build-image.yml&version=GBlab&line=2&lineEnd=8&lineStartColumn=1&lineEndColumn=17&lineStyle=plain&_a=contents), [AWS](https://dev.azure.com/ITSEN-Collection/Enterprise-Services/_git/ITSSM-Systems-Engineering?path=/ImageCreation/ImageCreation2.0/CI/aws-build-image.yaml&version=GBlab&line=1&lineEnd=8&lineStartColumn=1&lineEndColumn=1&lineStyle=plain&_a=contents) and [VmWare](https://dev.azure.com/ITSEN-Collection/Enterprise-Services/_git/ITSSM-Systems-Engineering?path=/ImageCreation/ImageCreation2.0/CI/vmware-build-image.yml&version=GBlab&line=1&lineEnd=7&lineStartColumn=1&lineEndColumn=17&lineStyle=plain&_a=contents) pipeline yaml files control the schedule each pipeline will be triggered.    
  2. Once a pipeline is triggered , it pulls the relevant yaml file from the [CI](https://dev.azure.com/ITSEN-Collection/Enterprise-Services/_git/ITSSM-Systems-Engineering?path=%2FImageCreation%2FImageCreation2.0%2FCI&version=GBmain&_a=contents) directory from the main branch and follows it's logic.
  3. Each Azure Agent from the [ITSSM Gold Image](https://dev.azure.com/ITSEN-Collection/Enterprise-Services/_settings/agentqueues?queueId=3393&view=agents) pool is frequently checking for jobs (Azure Builds) scheduled for it. In order to have Red Hat Support,    
  &nbsp;&nbsp;&nbsp;&nbsp;RHEL8 images are built on RHEL8 ADO agents ( wzlxpgldagnt01, walxpgldagnt01, w0lxpgldagnt01 ),while RHEL9 images are built on RHEL9 ADO agents    
  &nbsp;&nbsp;&nbsp;&nbsp;(wzlxpgldagnt02, walxpgldagnt02, w0lxpgldagnt03).        
  *Note*: **For systems that are expected to build more than 1 image at a time, we have 2 agents running on the same host.**    
  4. The agent starts by pulling the main branch from the [ITSSM-Systems-Engineering](https://dev.azure.com/ITSEN-Collection/Enterprise-Services/_git/ITSSM-Systems-Engineering) repository. All code relevant to the Image Builder is in [ImageCreation2.0](https://dev.azure.com/ITSEN-Collection/Enterprise-Services/_git/ITSSM-Systems-Engineering?path=/ImageCreation/ImageCreation2.0) directory.    
  5. The first job in each Pipeline is to retrieve the necessary secrets from the [wbggoldimagecreation](https://portal.azure.com/#@worldbankgroup.onmicrosoft.com/resource/subscriptions/7b4d1501-6351-4d0f-a681-0473c2221a05/resourceGroups/WBG-OS-Image/providers/Microsoft.KeyVault/vaults/wbggoldimagecreation/overview) keyvault and set them as Pipeline variables.    
  6. The pipeline replaces the secrets in the TOML files, assembles the Blueprint file (based on OS and Image type) and pushes it to the RH Image builder locally.    
  7. Once the image is created, the image builder pushes the Azure image to [wbgosbuildimagestorage](https://portal.azure.com/#@worldbankgroup.onmicrosoft.com/resource/subscriptions/7b4d1501-6351-4d0f-a681-0473c2221a05/resourceGroups/WBG-OS-Image/providers/Microsoft.Storage/storageAccounts/wbgosbuildimagestorage/overview) Storage Account , the AWS image to [wbgadmin-rh-builder](https://s3.console.aws.amazon.com/s3/buckets/wbgadmin-rh-builder?region=us-east-1&tab=objects) S3 bucket and    
  VmWare disk to "/Data/govc/" directory.
  8. Once the image is uploaded, it needs to be validated. For Azure we use PowerShell to create a "RHELXtest" VM in [WBG-OS-Image](https://portal.azure.com/#@worldbankgroup.onmicrosoft.com/resource/subscriptions/7b4d1501-6351-4d0f-a681-0473c2221a05/resourceGroups/WBG-OS-Image/overview) resource group, for AWS we use azure cli to create the 'RhImageBuilderTestMachine' EC2 Instance in the [WBG AWS Admin](https://us-east-1.console.aws.amazon.com/ec2/home?region=us-east-1) account and for VmWare we use govc binary to create a "RHELX_test" VM in the VmWare Production environment.    
  9. The next step is to [trigger a Nessus scanning](https://dev.azure.com/ITSEN-Collection/Enterprise-Services/_git/ITSSM-Systems-Engineering?path=/ImageCreation/ImageCreation2.0/Scripts/05_TriggerNessusScan.sh&version=GBmain) which uses the API to set the target's IP address and launch the scan.
  10. Nessus internally delegates the scan task to one of it's scanner systems.
  11. Finally it retrieves the scan results and analyzes them. In case of any "<span style='color:orange'>**Medium**</span>", "<span style='color:#F05C66'>**High**</span>" or "<span style='color:#FF000A'>**Critical**</span>" vulnerabilities detected or **failure to authenticate** with the test VM the script exits with an error.     
  12. Once the VM is no longer needed, the pipeline destroys it to conserve resources.    
  13. If no issues are detected during the scanning, the AWS AMI (IMAGE_KEY) is shared with all accounts, the Azure image is pushed to the [SecurityAccreditedGoldImages](https://portal.azure.com/#@worldbankgroup.onmicrosoft.com/resource/subscriptions/7b4d1501-6351-4d0f-a681-0473c2221a05/resourceGroups/wbg-os-image/providers/Microsoft.Compute/galleries/SecurityAccreditedGoldImages/overview) gallery, while for VmWare the image is pushed and converted into a regular template (twice - once for a possible rollback and then overwrites the one vra is looking for).
  <br></br>    
<p align="right">(<a href="#top">back to top</a>)</p>    

### **Usage**

### **Node Setup**
For Supportability , we need to build RHEL8 images on RHEL8 systems, while RHEL9 images on RHEL9 systems.    
Generally, we need a VM in each environment (AWS, Azure and VmWare) with enough resources to run the OS and the Image builder (CPUs: 2, RAM: 8GB) and a dedicated storage disk of 150GB (or more).    

Setup awscli on the AWS Node:
```shell
curl "https://awscli.amazonaws.com/awscli-exe-linux-x86_64.zip" -o "awscliv2.zip"
unzip awscliv2.zip
./aws/install
```

Setup govc binary on VmWare:
```shell
curl -L -o - "https://github.com/vmware/govmomi/releases/latest/download/govc_$(uname -s)_$(uname -m).tar.gz" | tar -C /usr/local/bin -xvzf - govc
```

Setup azure-cli and PowerShell on the Azure:
```shell
rpm --import https://packages.microsoft.com/keys/microsoft.asc
dnf install -y https://packages.microsoft.com/config/rhel/9.0/packages-microsoft-prod.rpm
dnf install powershell azure-cli
pwsh
Install-Module Az
```

Install auxiliary software on all nodes:
```shell
yum install tmux powershell mc git jq vim wget createrepo
```

Prepare the storage:
```shell
# Identify the data disk (hint: it's not used at all) and note down the sdX name
lsblk

# Prepare LVM
vgcreate osbuild /dev/sdX
lvcreate -L 25G -n var_cache_osbuild-composer osbuild
lvcreate -L 25G -n var_cache_osbuild-worker osbuild
lvcreate -l 100%FREE -n var_lib_osbuild-composer osbuild

# Prepare the File System
mkfs.xfs /dev/osbuild/var_cache_osbuild-composer
mkfs.xfs /dev/osbuild/var_cache_osbuild-worker
mkfs.xfs /dev/osbuild/var_lib_osbuild-composer

# Create the mountpoints
mkdir /var/lib/osbuild-composer/
mkdir /var/cache/osbuild-composer/
mkdir /var/cache/osbuild-worker/
```

Get the Disk UUID for each Logical Volume and prepare the '.mount' unit file.
The following is an example for the '/var/lib/osbuild-composer/' mountpoint:
```shell
## Get the File System UUID for the Logical Volume
[root@HOSTNAME ~]# ls -l /dev/osbuild/var_lib_osbuild-composer
lrwxrwxrwx 1 root root 7 Nov 15 04:41 /dev/osbuild/var_lib_osbuild-composer -> ../dm-7

[root@HOSTNAME ~]# ls -l /dev/disk/by-uuid/ | grep dm\-7
lrwxrwxrwx 1 root root 10 Nov 15 04:41 f285d4fc-52e1-4e9e-ab16-34dc1c21b5eb -> ../../dm-7

# Note down the result and replace it later instead of ###systemd-escape-result###
[root@HOSTNAME ~]# systemd-escape dev/disk/by-uuid/f285d4fc-52e1-4e9e-ab16-34dc1c21b5eb

# Create the unit file (\\x2d is replacing the "-" in "osbuild-composer")
vim /etc/systemd/system/var-lib-osbuild\\x2dcomposer.mount

# Example of unit file
[Unit]
Documentation=man:fstab(5) man:systemd-fstab-generator(8)
Before=local-fs.target
# Mount only after the disk was probed
# replace dashes in the uuid entry with \x2d sequence or use systemd-escape binary to get it for you
After=blockdev@###systemd-escape-result###.target

[Mount]
What=/dev/disk/by-uuid/f285d4fc-52e1-4e9e-ab16-34dc1c21b5eb # UPDATE !!!
Where=/var/lib/osbuild-composer # UPDATE !!!
Type=xfs
Options=defaults,nodev,nosuid

[Install]
WantedBy=multi-user.target
```

Reload the daemon and enable the mount point
```shell
systemctl daemon-reload
systemctl enable --now 'var-lib-osbuild\x2dcomposer.mount'
```

```shell
# Verify the outcome:
[root@HOSTNAME ~]# systemctl is-enabled 'var-lib-osbuild\x2dcomposer.mount'
enabled
[root@HOSTNAME ~]# systemctl is-active 'var-lib-osbuild\x2dcomposer.mount'
active

# Size can be different based on your disk space
[root@HOSTNAME ~]# df -h /var/lib/osbuild-composer/
Filesystem                                     Size  Used Avail Use% Mounted on
/dev/mapper/osbuild-var_lib_osbuild--composer  150G  1.1G  149G   1% /var/lib/osbuild-composer
```

</br>    

<span style='color:red'>**Repeat the previous procedure for /var/cache/osbuild-composer/ and /var/cache/osbuild-worker/ !**</span>
</br></br>    

Setup the Image Builder:
```shell
yum install osbuild-composer composer-cli
systemctl enable --now osbuild-composer.socket
```

Setup Azure DevOps Agent:
```shell
useradd srvtfs -g srvtfs
usermod -aG weldr srvtfs
mkdir /Data
chown srvtfs: /Data/
chmod 755 /Data/
su srvtfs -
cd /Data
# Create the GOVC directory only for VmWare
mkdir govc

mkdir tfsagent
cd tfsagent/
mkdir 01
cd 01/
```

Download the Agent from the [Azure DevOps portal](https://dev.azure.com/ITSEN-Collection/Enterprise-Services/_settings/agentqueues?queueId=3393&view=agents)
```shell
wget <URL>
```

Extract the archive and start the configuration as 'srvtfs' user:
```shell
[srvtfs@HOSTNAME 01]$ ./config.sh
```    

Naming convention used for ADO agents:    
<Env><EnvId>Agent<Id>
Env:
  - OnPrem
  - Azure
  - Amazon   
 
EnvID:
  - For RHEL8 -> 01
  - For RHEL9 -> 02    

Id:
  - ID of the agent on the system 

Note: Some systems have more than 1 agent for parallelism.

Example input for ADO agent setup (For refference only!):
```
Server: https://dev.azure.com/ITSEN-Collection
Agent pool: ITSSM Gold Image
# 
Agent name:
	OnPrem01Agent01
	OnPrem02Agent01
	Azure01Agent01
	Azure01Agent02
	Azure02Agent01
	Azure02Agent02
	Amazon01Agent01
	Amazon02Agent01
```

Start the ADO agent:
```shell
[root@HOSTNAME ~]# cd /Data/tfsagent/01/
[root@HOSTNAME ~]# ./svc.sh install srvtfs
[root@HOSTNAME ~]# ./svc.sh start
```    

Setup Local Repository:
```shell
mkdir /Data/REPO
cd /Data/REPO/
```

Obtain all packages that the local repo will contain:
```shell
# Get the latest version of chef-client from https://www.chef.io/downloads/tools/infra-client
curl  https://packages.chef.io/repos/yum/stable/el/9/x86_64/chef-18.3.0-1.el9.x86_64.rpm > chef-18.3.0-1.el9.x86_64.rpm
wget http://w0lxsatellite01.worldbank.org/pub/katello-ca-consumer-latest.noarch.rpm
mv katello-ca-consumer-latest.noarch.rpm katello-ca-consumer-w0lxsatellite01.worldbank.org.rpm
createrepo .
cd ..
chown _osbuild-composer: /Data/REPO -R
```

Define the local repo in Image Builder:
```shell
cd /root/

# Setup the local repo definition file
vim local_repo.toml
```

```toml

check_gpg = false
check_repogpg = false
check_ssl = false
id = "local_repo"
name = "local_repo"
rhsm = false
system = false
type = "yum-baseurl"
url = "file:///Data/REPO/"
```

Import the composer source file:
```shell
composer-cli sources add local_repo.toml
```
</br>    
<p align="right">(<a href="#top">back to top</a>)</p>  

### **Trigger an Image Build**

You can trigger the pipelines manually from the [RHEL](https://dev.azure.com/ITSEN-Collection/Enterprise-Services/_build?definitionScope=%5CITSSM-Systems-Engineering%5CGolden_Image%5CRHEL) directory.All variables are preset.    
</br>    
<p align="right">(<a href="#top">back to top</a>)</p>  

### **Troubleshooting**

This section will guide you in solving the most common problems:
  - **A build has failed:**    
    In case a build has failed, check the journal:
    ```shell
    journalctl -u osbuild-worker@\*.service -u osbuild-composer.service -e
    ```    
    Another place to look are the build logs:
    ```shell
    composer-cli compose logs <UUID of the build>
    tar -xvf <UUID>.tar
    ```    
  </br>

  - **Out of Space:**    
    When you have too many failed builds or several manual builds , you may end up out of space. In order to identify the affected component run:    
    ```shell
    df -h /var/cache/osbuild-worker /var/cache/osbuild-composer /var/lib/osbuild-composer
    ```      

    If */var/lib/osbuild-composer* is out of space, **clear any failed composes**, while if */var/cache/osbuild-worker/* or */var/cache/osbuild-composer/* are full, try **clearing the cache**.    
  </br>

  - **Clear failed composes:**    
    In general, you can delete any compose, but usually the failed ones are most suitable for cleanup:    
    ```shell
    for i in $(composer-cli  compose status | awk '/FAILED/ {print $1}'); do composer-cli compose delete $i ; done
    ```    
  </br>

  - **Clear the cache:**    
    When the cache directory is full you can execute the following when the composer is not building an image:
    ```shell
    {
    systemctl stop osbuild\*
    systemctl reset-failed osbuild\*
    rm -rf /var/cache/osbuild-worker/*
    rm -rf /var/cache/osbuild-composer/*
    systemctl start osbuild-composer.socket
    }
    ```   
  </br>

  - **Restart the whole stack:**
    ```shell
    {
    systemctl stop osbuild\*
    systemctl reset-failed osbuild\*
    systemctl start osbuild-composer.socket
    }  
    ```    
</br>    
<p align="right">(<a href="#top">back to top</a>)</p>  

### **Support**
  In order to [open a case](https://access.redhat.com/support/cases/#/case/new/get-support?caseCreate=true), you will need a <span style='color:red'>Red Hat Account</span> and ssh access to the system!    
  1. Open a case and fill in all fields requested by the wizzard. If it prompts you to upload data - just acknowledge the prompt.
  2. Once your case is open, you can collect an sos report from the system:    
      ```shell
      sos report --upload --upload-user 'MY_REDHAT_ACCOUNT' --upload-protocol https --case-id CASE_ID_from_previous_step
      ```
      Note: Follow the prompts and enter your password for the RH portal when requested.
  3. Validate that your sos report was uploaded to the portal.    
  4. You might be requested to provide additional data like the described in [RH Solution#6573781](https://access.redhat.com/solutions/6573781).    
  Don't forget that some of our systems have multiple *osbuild-worker*-s, so you need to repeat the steps for each worker.

</br>    
<p align="right">(<a href="#top">back to top</a>)</p>  
