#<div id="top"></div>

<!-- TABLE OF CONTENTS -->
<details>
  <summary>Table of Contents</summary>
   <li>
      <a href="#getting-started">Getting Started</a>
         <ul>
         <li><a href="#prerequisites">Prerequisites</a></li>
         <li><a href="#build-the-environment">Build the environment</a></li>
         <li><a href="#usage">Usage</a></li>
         </ul>
      </ul>
   </li>
   <li><a href="#contacts">Contacts</a></li>
   <li><a href="#source">Source location</a></li>

</details>


## Getting Started
<ul>
This section describes how to prepare your system for compilation of the source code
</ul>

### Prerequisites
1. Install Python 3.6 or higher
   ```sh
   # On RHEL 8/9 install python3 (minimum 3.6):
   yum install python36 python3-pip
   ```
<p align="right">(<a href="#top">back to top</a>)</p>

### Build the environment

1. Create a virtual environment
   ```sh
   python3 -m venv myvirtualenvironment
   ```
2. Copy the 3 source files to the virtual environment
   ```sh
   cp -t myvirtualenvironment CA.pem move_template.py requirements.txt
   cd myvirtualenvironment
   ls CA.pem move_template.py requirements.txt
   ```
3. Modify the shebang of the move_template.py to point the venv
   ```sh
   vim move_template.py
   # A sample shebang line for user "serviceaccount":    
       
   #!/home/serviceaccount/myvirtualenvironment/bin/python3
   ```
4. Install the dependencies
   ```sh
   # Verify that we are in myvirtualenvironment dir
   basename $(pwd)
   # Activate the venv
   source bin/activate
   # Install the dependencies
   pip install -r requirements.txt
   ```
4. Deactivate the venv
   ```sh
   deactivate
   ```
<p align="right">(<a href="#top">back to top</a>)</p>


## Usage

Execute the binary:
  - Linux:
    ```sh
    # Get help
    /home/serviceaccount/myvirtualenvironment/move_template.py --help
    # List all templates
    /home/serviceaccount/myvirtualenvironment/move_template.py -u <user> -p <pass> -l
    # Migrate a template to Gold_Image library
    /home/serviceaccount/myvirtualenvironment/move_template.py -u <user> -p <pass> -t vraXXXXXX -g <content library name>
    # Migrate a template to Gold_Image library and overwrite if existing
    /home/serviceaccount/myvirtualenvironment/move_template.py -u <user> -p <pass> -t vraXXXXXX -g <content library name> -o
    ```

<p align="right">(<a href="#top">back to top</a>)</p>

## Contacts
Strahil Nikolov - snikolov@worldbankgroup.org
<p align="right">(<a href="#top">back to top</a>)</p>

## Source
Project Link: [ImageCreation/VmWare](https://dev.azure.com/ITSEN-Collection/Enterprise-Services/_git/ITSSM-Systems-Engineering?path=/ImageCreation/VmWare)

<p align="right">(<a href="#top">back to top</a>)</p>
