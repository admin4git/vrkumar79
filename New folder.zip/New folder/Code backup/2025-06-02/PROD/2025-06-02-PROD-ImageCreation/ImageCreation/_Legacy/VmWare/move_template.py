#!/home/wb588963/template_migration/bin/python3
"""
    This Script lists/migrates templates from Test vCenter to the Gold_Image
    Content Library (synced with Prod vCenters)
"""
import ssl
import sys
import json
import argparse
import requests
from pyVmomi import vim # pylint: disable=no-name-in-module # type: ignore
from pyVim import connect # pylint: disable=no-name-in-module # type: ignore
from requests.auth import HTTPBasicAuth

def get_vim_objects(content, vim_type):
    '''Get vim objects of a given type.'''
    return [item for item in content.viewManager.CreateContainerView(content.rootFolder,
     [vim_type], recursive=True).view]

parser = argparse.ArgumentParser(description='Move a template to the "Gold_Image" Content Library.')
parser.add_argument('-u', '--username', required=True,
 type=str, default=None, help="VmWare vCenter user")
parser.add_argument('-p', '--password', required=True,
 type=str, default=None, help="VmWare vCenter user's password")
parser.add_argument('-t', '--template', required=False, type=str, default=None,
 help="Template that has to be imported into the Gold_Image Content Library.")
parser.add_argument('-l', '--list-templates',
 help="List all templates found on the vCenter and exit", action='store_true')
parser.add_argument('-g', '--gallery-name', required=True, type=str, default=None,
 help="Name of the target Content Gallery for the image import.")
parser.add_argument('-o', '--overwrite', action='store_true',
 help="Overwrite target template if found")
args = vars(parser.parse_args())

USERNAME = args['username']
PASSWORD = args['password']
template_name = args['template']
list_templates = args['list_templates']
gallery_name = args['gallery_name']
overwrite = args['overwrite']
TEMPLATE_ID = ""
VHOST = "wbgvmvctest01.wb.ad.worldbank.org"
baseurl = f"https://{VHOST}"

ctx = ssl.create_default_context()
ctx.load_verify_locations(sys.path[0] + "/CA.pem")

# vSphere Web Services API auth
si = connect.SmartConnect(host=VHOST,user=USERNAME,pwd=PASSWORD,port=443,sslContext=ctx)
vmcontent = si.RetrieveContent()
for vm in get_vim_objects(vmcontent, vim.VirtualMachine):
    if vm.config.template and vm.name == template_name:
        TEMPLATE_ID = str(vm).replace("'","").split(":")[1]
    if list_templates and vm.config.template:
        print(vm.name)

# Exit only if we requested to list the templates
if list_templates:
    sys.exit()
# If we haven't found any match after the loop
if not TEMPLATE_ID:
    sys.exit(f"Couldn't found the template {template_name}")

print(f"Our Source Template ID is: {TEMPLATE_ID}")

session = requests.session()
session.verify = sys.path[0] + '/CA.pem'

# vSphere Automation API (REST) auth
response = session.post(baseurl + "/rest/com/vmware/cis/session",
 auth=HTTPBasicAuth(USERNAME, PASSWORD)).json()
sessionid = response["value"]
session.headers['vmware-api-session-id'] = sessionid
session.headers['Content-Type'] = 'application/json'

payload = {}
payload["name"] = gallery_name
payload["type"] = "LOCAL"
submit_data = json.dumps(payload)
# Obtain the Gallery ID using the Gallery Name
response = session.post(baseurl + "/api/content/library?action=find",data = submit_data ).json()
library_id = response[0]

# Check if the template with the same name exists
if overwrite:
    payload = {}
    payload["library_id"] = library_id
    payload["name"] = template_name
    submit_data = json.dumps(payload)
    response = session.post(baseurl + "/api/content/library/item?action=find",
     data = submit_data ).json()
    if response[0]:
        library_item_id = response[0]

payload = {}
payload['create_spec'] = {}
payload['create_spec']['description'] = 'TEST_FROM_PYTHON'
payload['create_spec']['name'] = template_name
payload['source'] = {}
payload['source']['id'] = TEMPLATE_ID
payload['source']['type'] = 'VirtualMachine'
payload['target'] = {}
payload['target']['library_id'] = library_id
if overwrite and library_item_id:
    payload['target']['library_item_id'] = library_item_id

print("Our payload to move the Template to the library:")
print(json.dumps(payload, indent=4, sort_keys=True))
submit_data = json.dumps(payload)

response = session.post(baseurl + "/api/vcenter/ovf/library-item",data = submit_data ).json()

status = response["succeeded"]
# library_id = response["ovf_library_item_id"]

if status:
    library_id = response["ovf_library_item_id"]
    print(f"Move status: {status}, library item id: {library_id}")

elif response["error"]["errors"]:
    if response["error"]["errors"][0]["error"]["error_type"] == "ALREADY_EXISTS":
        sys.exit("Failed to move the template as it already exists! User '--overwrite' to replace it!")
else:
    error_message = response["error"]["errors"][0]["error"]["messages"][0]["default_message"]
    sys.exit(f"Upload failed with error: {error_message}\n\nCONSIDER USING THE '--overwrite'")
