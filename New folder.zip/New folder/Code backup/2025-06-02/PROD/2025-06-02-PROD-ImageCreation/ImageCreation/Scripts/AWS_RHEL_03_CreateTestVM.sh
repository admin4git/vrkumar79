#!/bin/bash
# shellcheck disable=2154

set -x
set -e

# Create the VM
IMAGE_ID=$(aws ec2 describe-images --filters "Name=name,Values=${VMNAME}" | jq -r '.Images[].ImageId')
INSTANCE_ID=$(aws ec2 run-instances --image-id "${IMAGE_ID}" --count 1 --instance-type t2.medium --key-name image-builder --security-group-ids sg-0b57d2bdd6447fd36 sg-09af912f95567ac7c sg-0c487f911e47fca0b --subnet-id subnet-0a549643342d36781 --tag-specifications "ResourceType=instance,Tags=[{Key=Name,Value=${VMNAME}},{Key=Project,Value=Gold image creation automation},{Key=LEAP,Value=WBG Cloud Computing Platform (AWS)},{Key=IO Code,Value=WBGAdmin},{Key=AWS Backup,Value=DailyProd90day_Midnight}]" | jq -r '.Instances[].InstanceId')
echo "$INSTANCE_ID"

# Update the IP variable

TESTVM_IP=$( aws ec2 describe-instances --instance-ids "${INSTANCE_ID}" --query 'Reservations[*].Instances[*].PrivateIpAddress' --output text)


echo "##vso[task.setvariable variable=TESTVM_IP;issecret=false;isOutput=true]$TESTVM_IP"
echo "##vso[task.setvariable variable=INSTANCE_ID;issecret=false;isOutput=true]$INSTANCE_ID"
echo "##vso[task.setvariable variable=IMAGE_ID;issecret=false;isOutput=true]$IMAGE_ID"
JSON_STRING=$( jq -n \
                  --arg os "$OSVersion" \
                  --arg vm "$VMNAME" \
                  --arg img "$IMAGE_ID" \
                  --arg vmss "$VMSS" \
                  '{OSVERSION: $os, VMSS: $vmss, VMNAME: $vm, IMAGE_ID: $img}' )
echo "$JSON_STRING" > variable.json