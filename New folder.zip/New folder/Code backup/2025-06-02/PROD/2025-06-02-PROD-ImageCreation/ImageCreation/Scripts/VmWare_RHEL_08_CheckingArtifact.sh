#!/bin/bash
result=$(cat "$1")
OSVersion=$(jq -r '.OSVERSION' <<< "${result}")
VMNAME=$(jq -r '.VMNAME' <<< "${result}")

echo "Loading Artifact variables as Azure Devops variables"
echo "##vso[task.setvariable variable=OSVersion;issecret=false]$OSVersion"
echo "##vso[task.setvariable variable=VMNAME;issecret=false]$VMNAME"
