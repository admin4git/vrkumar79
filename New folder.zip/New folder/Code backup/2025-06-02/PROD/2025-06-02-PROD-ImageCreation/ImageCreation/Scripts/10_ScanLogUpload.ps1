$scantype = "$($env:scantype)"
$OsVersion = "$($env:OSVersion)"
$cloudtag = "$($env:cloudtag)"
$vmname = "$($env:VMNAME)"
$vmip = "$($env:TESTVM_IP)"
$sourcefile = ""
$targetfile = ""
$container = ""
$cloudstring = ""

switch ($cloudtag) {
    "Z"
    {
        $cloudstring = "Azure"
    }
    "0"
    {
        $cloudstring = "VmWare"
    }
    "A"
    {
        $cloudstring = "Amazon"
    }
}
switch ($scantype) {
    "nessus" 
    {  
        $reportfile = Get-ChildItem NESSUSSCAN.NessusScan/ *.csv
        $sourcefile = $reportfile.FullName
        $targetfile = "$($OsVersion)_$($cloudstring)_NessusScan.csv" #$reportfile.Name
        $container = "nessus-report"
    }
    "inspec" 
    {
        $reportfile = Get-ChildItem INSPECSCAN.InspecScan/ *.json
        $sourcefile = $reportfile.FullName
        $targetfile = "$($OsVersion)_$($cloudstring)_InspecScan.json" #$reportfile.Name
        $container = "reports"

        $jsons = Get-Content $sourcefile -Raw
        $json = ConvertFrom-Json $jsons
        $json.platform | Add-Member environment "$cloudstring"
        $json.platform | Add-Member vmname "$vmname"
        $json.platform | Add-Member vmip "$vmip"
        $json.platform | Add-Member scantime "$([datetime]::Now) $([System.TimeZoneInfo]::Local)"
        $jsons2 = ConvertTo-Json $json -Depth 100
        $jsons2 | Set-Content $sourcefile
    }
    Default {}
}

$secret = ""
$EncodedSecret = "$($env:azurestoragekey)"
#Write-Output "Received secret: $EncodedSecret"
if (![string]::IsNullOrWhiteSpace($EncodedSecret))
{
    $secret = [System.Text.Encoding]::Unicode.GetString([System.Convert]::FromBase64String($EncodedSecret))
}

Write-Output "Uploading $scantype logs as $targetfile..."
$ctx = New-AzStorageContext -StorageAccountName wbgosbuildimagestorage  -StorageAccountKey $secret
Set-AzStorageBlobContent -File "$sourcefile" -Container $container -Blob $targetfile -Context $ctx -BlobType Block -Force
