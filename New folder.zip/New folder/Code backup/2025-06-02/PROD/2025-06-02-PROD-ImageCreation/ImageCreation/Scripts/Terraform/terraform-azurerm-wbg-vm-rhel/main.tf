terraform {
  required_providers {
    azurerm = {
      source                = "hashicorp/azurerm"
      version               = ">= 3.3.0"
      configuration_aliases = [azurerm.gallery-sub]
    }
  }
}

data "azurerm_subscription" "current" {}

data "tfe_workspace" "test" {
  name         = terraform.workspace
  organization = "Worldbank"
}

data "azurerm_shared_image_gallery" "gallery" {
  provider            = azurerm.gallery-sub
  name                = "SecurityAccreditedGoldImages"
  resource_group_name = "WBG-OS-Image"
}

data "azurerm_shared_image" "goldimage" {
  provider            = azurerm.gallery-sub
  name                = "RHEL${var.VM_OSVersion}-Accredited-image-LVM"
  gallery_name        = data.azurerm_shared_image_gallery.gallery.name
  resource_group_name = data.azurerm_shared_image_gallery.gallery.resource_group_name
}

data "azurerm_shared_image_version" "goldimage_version" {
  provider            = azurerm.gallery-sub
  name                = "latest" # "recent" is also a tag to use the most recent image version
  image_name          = data.azurerm_shared_image.goldimage.name
  gallery_name        = data.azurerm_shared_image.goldimage.gallery_name
  resource_group_name = data.azurerm_shared_image.goldimage.resource_group_name
}

data "external" "MachineCheck" {
  program = ["curl", "-q", "https://wbginfrastructureautomation.itssm-common-asev3-prod.appserviceenvironment.net/api/GetNextVMNumber?name=${local.vm_nameprefix}&wsid=${data.tfe_workspace.test.id}&os=Linux"]
}

data "azurerm_virtual_network" "VNet" {
  provider            = azurerm
  name                = var.VM_VirtualNetworkName
  resource_group_name = var.VM_VirtualNetworkRGName
}

data "azurerm_subnet" "Subnet" {
  provider             = azurerm
  name                 = var.VM_VirtualNetworkSubnetName
  resource_group_name  = data.azurerm_virtual_network.VNet.resource_group_name
  virtual_network_name = data.azurerm_virtual_network.VNet.name
}

resource "azurerm_network_interface" "Nic" {
  provider            = azurerm
  name                = "${local.vm_name}-nic"
  location            = var.VM_Location
  resource_group_name = var.VM_ResourceGroupName

  ip_configuration {
    name                          = "internal"
    subnet_id                     = data.azurerm_subnet.Subnet.id
    private_ip_address_allocation = "Dynamic"
  }
  tags = merge(
    tomap({
      MissionCritical         = "${var.TAG_MissionCritical}"
      OS                      = "Linux"
      AppType                 = "${var.TAG_AppType}"
      Description             = "${var.TAG_Description}"
      Client_Unit             = "${var.TAG_ClientUnit}"
      ENV                     = "${var.VM_Environment}"
      Security_Classification = "${var.TAG_SecurityClassification}"
      DeployedBy              = "${data.tfe_workspace.test.id}"
      Leap                    = "${var.Leap}"
  }), var.additional_tags)
}

resource "azurerm_linux_virtual_machine" "VM" {
  provider            = azurerm
  name                = local.vm_name
  resource_group_name = var.VM_ResourceGroupName
  location            = var.VM_Location
  size                = var.VM_HostSize
  license_type        = "RHEL_BYOS"
  admin_username      = "vra"
  zone                = var.VM_Zone == null ? element(tolist(["1", "2", "3"]), var.current_count) : var.VM_Zone[var.current_count]
  # Timeouts block to increase the timeout
  timeouts {
    create = "60m"  # Increase creation timeout to 60 minutes
    update = "30m"  # Increase update timeout to 30 minutes
    delete = "30m"  # Increase deletion timeout to 30 minutes
  }
  additional_capabilities {
    ultra_ssd_enabled = true
  }
  network_interface_ids = [
    azurerm_network_interface.Nic.id,
  ]
  identity {
    type = "SystemAssigned"
  }
  boot_diagnostics {}

  tags = merge(
    tomap({
      MissionCritical         = "${var.TAG_MissionCritical}"
      OS_FLavour              = "RHEL${var.VM_OSVersion}"
      OS                      = "Linux"
      AppType                 = "${var.TAG_AppType}"
      Description             = "${var.TAG_Description}"
      Client_Unit             = "${var.TAG_ClientUnit}"
      ENV                     = "${var.VM_Environment}"
      Security_Classification = "${var.TAG_SecurityClassification}"
      DeployedBy              = "${data.tfe_workspace.test.id}"
      Leap                    = "${var.Leap}"
  }), var.additional_tags)

  disable_password_authentication = true
  admin_ssh_key {
    username   = "vra"
    public_key = "ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQDH8/whD+k2bGOWttQ6GmgsH2h1coc+kX3MlQG6jmoxP/mBJNxjU+SFAoTWARqj9OwhjBc8BTQ7q0dijimFUipJBc94m70qUgS5bgVgiPT5mUM3zE8a/PRMHedJ8rqhpH97IUAywu2eka52hdQswE24u27LP622nkJn8MTOAP9NgH3ODuzSeuv9oBIueWi0CGR18W7gqv6jicVfRx7O9vEAxuKfBRN+nb8BdZWkqbJcHjK1UKaqJ1MrmJ6xPl/b7s5krTc85H/lJWj2cyVSSzhVNjQz8Yqmz0Vq/turAJsPUsImeKx4wTxgVSOIMlztbhBCsMnz+pWFF7ozbwEutUC5"
  }

  os_disk {
    caching              = "ReadWrite"
    storage_account_type = "Standard_LRS"
  }

  lifecycle {
    prevent_destroy = false
  }

  source_image_id = data.azurerm_shared_image_version.goldimage_version.id
}


resource "null_resource" "node_clean_up" {

  triggers = {

    hostname = "${azurerm_linux_virtual_machine.VM.name}"

  }

  provisioner "local-exec" {

    when    = destroy
    command = "curl -o chef_node_delete.sh http://w0lxsatellite01.worldbank.org/pub/Files/server_build/node_cleanup.sh"
  }

  provisioner "local-exec" {
    when    = destroy
    command = "bash chef_node_delete.sh ${self.triggers.hostname}"
  }

}

resource "azurerm_virtual_machine_extension" "executeScripts" {
  name                 = local.vm_name
  virtual_machine_id   = azurerm_linux_virtual_machine.VM.id
  publisher            = "Microsoft.Azure.Extensions"
  type                 = "CustomScript"
  type_handler_version = "2.0"
  tags = merge(
    tomap({
      MissionCritical         = "${var.TAG_MissionCritical}"
      OS_FLavour              = "RHEL${var.VM_OSVersion}"
      OS                      = "Linux"
      AppType                 = "${var.TAG_AppType}"
      Description             = "${var.TAG_Description}"
      Client_Unit             = "${var.TAG_ClientUnit}"
      ENV                     = "${var.VM_Environment}"
      Security_Classification = "${var.TAG_SecurityClassification}"
      DeployedBy              = "${data.tfe_workspace.test.id}"
      Leap                    = "${var.Leap}"
  }), var.additional_tags)

  settings = <<SETTINGS
    {
        "fileUris": [ "https://wbgitssmterraformstorage.blob.core.windows.net/terraform/linuxboot.sh?sp=r&st=2023-11-14T15:20:33Z&se=2030-11-13T22:00:00Z&spr=https&sv=2022-11-02&sr=b&sig=tLtHlaJbBwOiF1UHp3RC%2FOONU%2F6um7WrXBUniuOajdI%3D" ],
        "commandToExecute": "bash ./linuxboot.sh ${local.vm_name} ${var.VM_ChefRole} ${local.chefenvironment_name}   ${join(" ", var.VM_ExistingHostGroups)} &> /var/log/linuxboot.log"
    }
SETTINGS


  depends_on = [
    azurerm_virtual_machine_data_disk_attachment.datadisk
  ]


}

resource "azurerm_managed_disk" "datadisk" {
  for_each                      = { for line in var.lunmap : line.name => line }
  name                          = "${azurerm_linux_virtual_machine.VM.name}-${each.value.name}"
  location                      = var.VM_Location
  resource_group_name           = var.VM_ResourceGroupName
  storage_account_type          = each.value.storage_account_type
  create_option                 = "Empty"
  disk_iops_read_write          = each.value.disk_iops_read_write == null ? null : each.value.disk_iops_read_write
  disk_iops_read_only           = each.value.disk_iops_read_only == null ? null : each.value.disk_iops_read_only
  disk_mbps_read_write          = each.value.disk_mbps_read_write == null ? null : each.value.disk_mbps_read_write
  disk_mbps_read_only           = each.value.disk_mbps_read_only == null ? null : each.value.disk_mbps_read_only
  disk_size_gb                  = each.value.size_in_gb
  public_network_access_enabled = false
  network_access_policy         = "DenyAll"
  # Commented out due to the following error:
  # Error: waiting for Virtual Machine "Virtual Machine: (Name \"wzlxdmodtest01\" / Resource Group \"strahil-test-lin-module\")" to finish updating Disk "wzlxdmodtest01-datadisk2":
  # Code="NotSupported" Message="Disk '/subscriptions/64c555a9-193a-4e08-af9d-daaa32034faa/resourceGroups/strahil-test-lin-module/providers/Microsoft.Compute/disks/wzlxdmodtest01-datadisk1'
  # contains encryption settings and cannot be used as a data disk.
  # In order to use it as a data disk, remove the encryption settings and ensure that the virtual machine’s OS disk has the applicable encryption settings defined."

  #   dynamic encryption_settings {
  #     for_each = each.value.disk_encryption_secret_id != null && each.value.disk_encryption_vault_id != null ? tolist([1]) : []
  #     content {
  #       disk_encryption_key {
  #         secret_url = each.value.disk_encryption_secret_id
  #         source_vault_id = each.value.disk_encryption_vault_id
  #       }
  #     }
  #   }
  zone = var.VM_Zone == null ? element(tolist(["1", "2", "3"]), var.current_count) : var.VM_Zone[var.current_count]
  tags = merge(
    tomap({
      MissionCritical         = "${var.TAG_MissionCritical}"
      OS                      = "Linux"
      AppType                 = "${var.TAG_AppType}"
      Description             = "${var.TAG_Description}"
      Client_Unit             = "${var.TAG_ClientUnit}"
      ENV                     = "${var.VM_Environment}"
      Security_Classification = "${var.TAG_SecurityClassification}"
      DeployedBy              = "${data.tfe_workspace.test.id}"
      Leap                    = "${var.Leap}"
  }), var.additional_tags)
}


resource "azurerm_virtual_machine_data_disk_attachment" "datadisk" {
  for_each           = { for line in var.lunmap : line.name => line }
  managed_disk_id    = "${data.azurerm_subscription.current.id}/resourceGroups/${var.VM_ResourceGroupName}/providers/Microsoft.Compute/disks/${azurerm_linux_virtual_machine.VM.name}-${each.value.name}"
  virtual_machine_id = azurerm_linux_virtual_machine.VM.id
  lun                = (index(keys(azurerm_managed_disk.datadisk), each.value.name) + 1)
  caching            = each.value.caching
}
