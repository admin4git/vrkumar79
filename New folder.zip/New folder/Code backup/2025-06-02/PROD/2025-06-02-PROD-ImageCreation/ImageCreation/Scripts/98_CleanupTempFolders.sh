#!/bin/bash

echo "Removing failed and finished builds from the builder system"
{
    idlist=$( composer-cli compose status -j | jq -r '.[].body | select(.finished, .failed)[] | .[].id' )
    for uuid in $idlist
    do
        composer-cli compose delete "$uuid"
    done
}
echo "Stopping osbuilder services"
sudo systemctl stop osbuild\*
sudo systemctl reset-failed osbuild\*

echo "Deleting temporary folders and files"
sudo rm -rf /var/cache/osbuild-worker/*
sudo rm -rf /var/cache/osbuild-composer/*
sudo rm -rf /var/lib/osbuild-composer/artifacts/*

echo "Starting osbuilder services"
sudo systemctl start osbuild-composer.socket