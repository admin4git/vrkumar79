#!/usr/bin/python3

#pylint: disable=C0301
"""InSpec test script"""
import argparse
import subprocess
import socket
from datetime import datetime
import json
import os
import tarfile
import re
import shutil
import ipaddress
import requests
import paramiko # type: ignore
import sys


def check_host_availability(hostname):
    """Determines the ip address by hostname and checks the availability"""

    try:
        try:
            ip_address = str(ipaddress.ip_address(hostname))
        except:
            print("Determine ip address by hostname")
            ip_address = socket.gethostbyname(hostname)
            print(f"Ip address for host {hostname} - {ip_address}")

        print(f"Checking availability {hostname}")

        # ping from Linux
        #result = subprocess.run(["ping", "-c", "4", ip_address], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, check=False, shell=False)
        result = subprocess.run(["ping", "-c", "4", ip_address], stdout=subprocess.PIPE, text=True, check=False, shell=False)
        if ip_address and "4 packets transmitted, 4 received" in result.stdout:

        # ping from Windows
        # result = subprocess.run(["ping", "-n", "2", ip_address], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, check=False)
        # if ip_address and "Packets: Sent = 2, Received = 2" in result.stdout:
            print("Host responds to ping")
            return True
        else:
            print("Host does not respond to ping")
            return False

    except socket.gaierror:
        print("Error getting ip address from hostname")
        return False
    except subprocess.CalledProcessError:
        print("Error checking host availability")
        return False

def create_directory_if_not_exists(directory):
    """Function to create directory"""
    try:
        if not os.path.exists(directory):
            os.makedirs(directory)
            print(f"Directory created: {directory}")

    except OSError:
        print(f"Error creating directory: {directory}")
        sys.exit(1)

def delete_directory(profile_derectory):
    """Function to delete profile directory"""
    try:
        shutil.rmtree(profile_derectory)
        print(f"Directory {profile_derectory} was successfully deleted")
    except OSError as e_delete_dir:
        print(f"Error deleting directory {profile_derectory}: {e_delete_dir}")

def get_osversion(hostname, portssh, username, authenticationtype, authentication):
    """Get the version of the OS on the remote server"""

    # Create an SSHClient object
    client = paramiko.SSHClient()
    # Load known_hosts files
    client.load_system_host_keys()
    # Add a new host
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())

    try:
        if authenticationtype == "key":
            # In case of connection via ssh using a private key
            client.connect(hostname, port=portssh, username=username, key_filename=authentication, timeout=10)
        elif authenticationtype == "password":
            # In case of connection via ssh using the user password
            client.connect(hostname, port=portssh, username=username, password=authentication, timeout=10)
        else:
            raise ValueError("Invalid value for 'authenticationtype' parameter.")

        # Execute a command on the remote server to get OS version information
        command = 'cat /etc/redhat-release'
        _, stdout, _ = client.exec_command(command)

        # Read the command execution result and extract the OS version
        rhel_version = stdout.read().decode('utf-8').strip()
        print(f"Operating system: {rhel_version}")
        match = re.search(r'\b\d+\b', rhel_version)

        if match:
            osversion = match.group()
            # print(f"RHEL version - {osversion}")
            return osversion

        else:
            print("OS version detection error")
            sys.exit(1)

    except Exception as e_getos_ver:
        print(f"Error connecting to the remote server: {e_getos_ver}")
        sys.exit(1)

    finally:
        # Close connection
        client.close()

def profile_download(profiledata, profile_derectory):
    """Downloads the appropriate version of the scan profile from the Chef Automation server"""

    try:
        currentlocation = os.getcwd()
        currentlocation = currentlocation.replace("\\", "/")
        chefautomationfqdn = "https://w0lxqchefau02.worldbank.org"
        url = f"{chefautomationfqdn}/apis/iam/v2/policies"
        token = "¤chefinspectoken¤"
        urlprofile = f"{chefautomationfqdn}/api/v0/compliance/profiles"
        headers = {"api-token": token}
        response = requests.get(url, headers=headers, timeout=5)

        if response.status_code == 200:
            print(f"Successful loged in to Chef server - {chefautomationfqdn}")

            print("Search for all available profiles on the Chef automation server")
            urlprofilesearch = f"{urlprofile}/search"
            responsesearch = requests.post(urlprofilesearch, headers=headers, timeout=60)

            if responsesearch.status_code == 200:

                print("Saving the entire list of available scanning profiles from Chef automation server to a json file")
                profilelist = responsesearch.json()

                profilelistjson = json.dumps(profilelist, indent=4)
                file = open(f"{profile_derectory}ProfileList.json", "w", encoding="utf-8")
                file.write(profile_derectory+profilelistjson)
                file.close()
                print(f"List of available scan profiles saved in file: {profile_derectory}ProfileList.json")

                if profilelist:
                    print(f"Search for the required scan profile by name\nScan profile name: {profiledata['name']}")

                    for profile in profilelist['profiles']:

                        if profile['name'] == profiledata['name']:
                            print("Required profile found")
                            profiledata['version'] = profile['version']
                            print(f"Profile: {profile['name']}, with version: {profile['version']} found on the Chef automation server")

                            # Print a list of all available profiles
                            # print(f"Profile name: {profile['name']}, title: {profile['title']}, version: {profile['version']}")
                            break

                else:
                    print(f"There are no scan profile: {profile['name']} available on the Chef automation server")
                    sys.exit(1)

                if profiledata['version']:

                    print("Downloading a scanning profile")
                    urlprofiletar = f"{urlprofile}/tar"
                    headerstar = {"x-data-collector-token": token, "Content-Type": "application/json"}
                    responsetar = requests.post(urlprofiletar, headers=headerstar, data=json.dumps(profiledata), timeout=10)

                    print("Checking the success of the request")
                    if responsetar.ok:
                        print("Saving the tar.gz scan profile archive from the Chef automation server to file")
                        newprofile_directory = f"{profile_derectory}{profiledata['name']}-{profiledata['version']}"
                        tarfilename = f"{newprofile_directory}.tar.gz"
                        with open(tarfilename, "wb") as tar_file:
                            tar_file.write(responsetar.content)
                        print(f"Compliance profile: '{profiledata['name']}' successfully downloaded to file: {tarfilename}")

                        print("Unpack the tar.gz archive into a folder with the same name")
                        os.makedirs(newprofile_directory, exist_ok=True)

                        with tarfile.open(tarfilename, "r:gz") as tar_archive:
                            tar_archive.extractall(newprofile_directory)
                        print(f"Tar.gz archive was successfully unpacked into folder: {newprofile_directory}")

                        return profiledata

                    else:
                        print(f"Error downloading compliance profile: {responsetar.status_code}, {responsetar.text}")
                        sys.exit(1)

            else:
                print(f"Error when retrieving a list of scan profiles: {responsesearch.status_code}")
                sys.exit(1)

        else:
            print(f"Error when accessing API: {response.status_code}")
            sys.exit(1)

    except Exception as e_profile_dld:
        print(f"An unexpected error occurred: {str(e_profile_dld)}")
        sys.exit(1)

def run_inspec_test(hostname, username, authenticationtype, authentication, portssh, testname, ostype, osversion, reporttype):
    """Function to scan a target via InSpec"""

    currentlocation = os.getcwd().replace("\\", "/")
    reports_directory = f"{currentlocation}/reports/"
    profile_derectory = f"{currentlocation}/profiles/"

    try:

        if ostype == "linux":

            if check_host_availability(hostname):

                if osversion is None:
                    print("The OS version is not specified in the parameters. Retrieving OS version")
                    osversion = get_osversion(hostname, portssh, username, authenticationtype, authentication)

                    if osversion is None:
                        print("OS version is not defined. Aborting InSpec test.")
                        return

                # Create directories if they don't exist
                create_directory_if_not_exists(reports_directory)
                create_directory_if_not_exists(profile_derectory)

                # Determine the scanning profile based on the OS version
                profiledata = {
                    "name": f"cis-rhel{osversion}-level1-server",
                    "version": ""
                }

                # Start the process of checking and loading the scanning profile
                profiledata = profile_download(profiledata, profile_derectory)

                testpath = f"{profile_derectory}{profiledata['name']}-{profiledata['version']}/controls/"
                test = testpath + testname
                print(f"Profile will be used for scanning: {test}")

                currentdate = datetime.now()
                formatted_date = currentdate.strftime("%Y%m%d_%H%M")
                # print('Date and Time is:', formatted_date)

                report_extensions = {
                    "cli": ".txt",
                    "documentation": ".txt",
                    "html2": ".html",
                    "progress": "",
                    "progress-bar": "",
                    "json": ".json",
                    "json-min": ".json",
                    "json-rspec": ".json",
                    "junit2": ".xml",
                    "yaml": ".yaml"
                }

                file_extension = report_extensions.get(reporttype, "")

                if not file_extension:
                    report_file=""

                report_file = f":{reports_directory}{hostname}_InSpec_UNIX_TIME{formatted_date}{file_extension}"

                # eulaconnection_string = [
                #     'inspec', 'exec',
                #     '--chef-license', 'accept-silent'
                # ]

                # # Accept EULA license
                # # result = subprocess.run(eulaconnection_string, check=False, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE, timeout=300)
                # eularesult = subprocess.run(eulaconnection_string, check=False, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=300)
                # # for debug
                # print(eularesult.stdout)

                # Possible inspec exit codes
                exit_code_descriptions = {
                    0: "Normal exit, all tests passed",
                    1: "Usage or general error",
                    2: "Error in plugin system",
                    3: "Fatal deprecation encountered",
                    100: "Normal exit, at least one test failed",
                    101: "Normal exit, at least one test skipped but none failed",
                    172: "Chef License not accepted"
                }

                if authenticationtype == "key":
                    connection_string = [
                        'inspec', 'exec', f'{test}',
                        '--target', f'ssh://{username}@{hostname}:{portssh}',
                        '--backend', 'ssh',
                        '--key-files', f'{authentication}',
                        '--reporter', f'{reporttype}{report_file}',
                        '--chef-license', 'accept-silent'
                    ]
                    print(f"Parameters for launching InSpec: {connection_string}")
                elif authenticationtype == "password":
                    connection_string = [
                        'inspec', 'exec', f'{test}',
                        '--target', f'ssh://{username}:{authentication}@{hostname}:{portssh}',
                        '--backend', 'ssh',
                        '--reporter', f'{reporttype}{report_file}',
                        '--chef-license', 'accept-silent',
                        '--sudo'
                    ]
                    print(f"Parameters for launching InSpec: hidden")
                    # print(f"Parameters for launching InSpec: {connection_string}") # !!! The account PASSWORD will be visible in connection string !!!
                else:
                    raise ValueError("Authentication type must be either key or password.")

                # Start of testing by InSpec
                #-result = subprocess.run(connection_string, check=False, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE, timeout=300)
                result = subprocess.run(connection_string, check=False, stdout=subprocess.DEVNULL, timeout=300)

                # Exit code check
                if result.returncode in [0, 100, 101]:
                    print(f"InSpec test completed successfully with exit code {result.returncode}: {exit_code_descriptions[result.returncode]}")
                elif result.returncode in [1, 2, 3, 172]:
                    print(f"Error running InSpec test: Exit code {result.returncode}:  {exit_code_descriptions[result.returncode]}")
                else:
                    print(f"Error running InSpec test: Exit code {result.returncode}")
                    print(f"Stderr: {result.stderr}")

                report_file = report_file[1:]

                if os.path.exists(report_file):
                    print(f"Report successfully created: {report_file}")
                    # with open(report_file, 'r', encoding='utf-8') as json_file:
                    #         print("Content of JSON file:")
                    #         print(json_file.read())

                    if file_extension == "json":
                        # Create a formatted copy of the JSON report file
                        print("Read json report and formatting")
                        with open(report_file, 'r', encoding='utf-8') as json_file:
                            json_data = json.load(json_file)
                            formatted_json = json.dumps(json_data, indent=4)

                        formatted_json_file = f"{currentlocation}/reports/{hostname}_{formatted_date}_formatted.json"
                        print(f"Save formatted json in file: {formatted_json_file}")
                        with open(formatted_json_file, 'w', encoding='utf-8') as formatted_json_file:
                            formatted_json_file.write(formatted_json)

                else:
                    print(f"Report file {report_file} was not created")
                    sys.exit(1)

                delete_directory(profile_derectory)

            else:
                print(f"Host {hostname} is not available.")
                sys.exit(1)

        elif ostype == "windows":
            print("Automation for Windows systems is currently not available")
            sys.exit(1)

        else:
            print("Any other types of systems other than Linux and Windows are not currently supported")
            sys.exit(1)

    except subprocess.CalledProcessError as error:
        #-print(f"Error running InSpec test: {error.stderr}")
        print(f"Error running InSpec test ... ")
        sys.exit(1)

if __name__ == "__main__":

    try:
        parser = argparse.ArgumentParser(add_help=False,description='Run InSpec tests with specified parameters.')
        parser.add_argument('-h', '--help', action='help', help='show this help message and exit')
        parser.add_argument('-t', '--target', required=False, type=str, help='Hostname or ip address for InSpec tests')
        parser.add_argument('-u', '--username'.strip(), required=False, type=str, default='chef-inspec', help='Username for ssh connection')
        parser.add_argument('-a', '--authenticationtype'.strip(), required=False, type=str, default='password', choices=['key', 'password'], help='Authentication method for ssh: key or password (default is password)')
        parser.add_argument('-r', '--reporttype'.strip(), required=False, type=str, default='json', choices=['cli', 'documentation', 'html2', 'progress', 'progress-bar', 'json', 'json-min', 'json-rspec', 'junit2', 'yaml'], help='Enable one or more output reporters: cli, documentation, html, progress, progress-bar, json, json-min, json-rspec, junit, yaml (default is json)')
        parser.add_argument('-p','--port'.strip(), required=False, type=str, default='22', help='Target port (default is 22)')
        parser.add_argument('-i', '--inspecprofile'.strip(), required=False, type=str, default='translated-controls.rb', help='Name of the InSpec test file (default is translated-controls.rb)')
        parser.add_argument('-o', '--ostype', required=False, type=str, default='linux', choices=['windows', 'linux'], help='OS type (default for now is linux)')
        parser.add_argument('-v', '--osversion', required=False, type=str, help='OS version')
        args = parser.parse_args()

        if not args.target:
            args.target = input("Enter the host name or ip address for InSpec tests: ").strip()
        if not args.username:
            args.username = input("Enter the username for SSH connection: ").strip()

        if args.authenticationtype == "key":
            # In case of connection via ssh using a private key
            authentication=os.getenv('DOWNLOADSECUREFILE_SECUREFILEPATH')
        elif args.authenticationtype == "password":
            # In case of connection via ssh using the user password
            authentication = "¤inspecpassword¤"
        else:
            raise Exception("Invalid authentication type! Please provide either \"password \" (for password based authentication) or \"key\" (for private key based authentication)")

        run_inspec_test(hostname=args.target, username=args.username, authenticationtype=args.authenticationtype, authentication=authentication, portssh=args.port, testname=args.inspecprofile, ostype=args.ostype, osversion=args.osversion, reporttype=args.reporttype )

    except Exception as e:
        print(f"An unexpected error occurred: {str(e)}")
        sys.exit(1)
