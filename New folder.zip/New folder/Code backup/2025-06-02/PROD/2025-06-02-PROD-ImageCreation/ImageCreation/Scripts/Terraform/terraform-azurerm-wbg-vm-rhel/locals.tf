locals {
  osversion_name       = var.VM_OSVersion == "9" ? "redhatlinux9" : var.VM_OSVersion == "8" ? "redhatlinux8" : ""
  chefenvironment_name = lower(var.VM_Environment) == "stage" ? "staging" : lower(var.VM_Environment)
  # deployrg_name = var.VM_ResourceGroupName # "${data.external.RGcheck.result.name}"
  # deployrg_location = var.VM_Location # "${data.external.RGcheck.result.location}"
  environment_short = lower(var.VM_Environment) == "prod" ? "P" : lower(var.VM_Environment) == "qa" ? "Q" : lower(var.VM_Environment) == "dev" ? "D" : "T"
  function_url      = lower(var.VM_Environment) == "prod" ? "prd" : lower(var.VM_Environment) == "qa" ? "qa" : lower(var.VM_Environment) == "dev" ? "dev" : "lab"
  vm_orgname        = lower(var.VM_Organization) == "tre" ? "TRE" : "W"
  vm_nameprefix     = "${local.vm_orgname}ZLX${local.environment_short}${var.VM_HostName}"
  # vm_name = var.vmname_override == "" ? lower("${local.vm_nameprefix}${data.external.MachineCheck.result.counter}") : var.vmname_override
  # We take the result from the Azure Function that gives the first available VM identifier id
  # and then we add the current count to it. If function id = 01 and this is the first vm deployed (via counter) - the result remains 01
  # if this is the second vm - the result will be 02 and so on
  vmid    = format("%02d", sum([data.external.MachineCheck.result.counter, var.current_count]))
  vm_name = var.vmname_override == "" ? lower("${local.vm_nameprefix}${local.vmid}") : var.vmname_override
  # The module will no longer create the RG. This code is for refference how to retrieve data from azapi resources
  # rg_exists = contains(jsondecode(data.azapi_resource_action.rg_resources.output).value[*].name, var.VM_ResourceGroupName)
}
