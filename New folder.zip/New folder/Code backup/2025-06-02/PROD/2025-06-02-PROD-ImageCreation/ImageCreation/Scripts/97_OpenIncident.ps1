$CBUILDID = $($env:COMPSER_BUILDID)
$VMNAME = $($env:VMNAME)
$OSVersion = $($env:OSVersion)
$sourcebranch = $($env:sourcebranch)
$buildername = $($env:buildername)
$cloudtag = $($env:cloudtag)
$collectionurl = $($env:collectionurl)
$projectname = $($env:projectname)
$buildid = $($env:buildid)
$vmss = " "
if ($($env:VMSS).ToString().ToLower() -eq "true") 
{
  $vmss = " VMSS "
}

if ($sourcebranch -eq "prod") 
{
  $EncodedSecret = [System.Environment]::GetEnvironmentVariable("snowprduser")
  if (![string]::IsNullOrWhiteSpace($EncodedSecret))
  {
    $user = [System.Text.Encoding]::Unicode.GetString([System.Convert]::FromBase64String($EncodedSecret))
  }
  $EncodedSecret = [System.Environment]::GetEnvironmentVariable("snowprdpass")
  if (![string]::IsNullOrWhiteSpace($EncodedSecret))
  {
    $pass = [System.Text.Encoding]::Unicode.GetString([System.Convert]::FromBase64String($EncodedSecret))
  }
  $EncodedSecret = [System.Environment]::GetEnvironmentVariable("snowprdurl")
  if (![string]::IsNullOrWhiteSpace($EncodedSecret))
  {
    $url = [System.Text.Encoding]::Unicode.GetString([System.Convert]::FromBase64String($EncodedSecret))
  }
  $targetenv = "prod"
}
else
{
  $EncodedSecret = [System.Environment]::GetEnvironmentVariable("snowqauser")
  if (![string]::IsNullOrWhiteSpace($EncodedSecret))
  {
    $user = [System.Text.Encoding]::Unicode.GetString([System.Convert]::FromBase64String($EncodedSecret))
  }
  $EncodedSecret = [System.Environment]::GetEnvironmentVariable("snowqapass")
  if (![string]::IsNullOrWhiteSpace($EncodedSecret))
  {
    $pass = [System.Text.Encoding]::Unicode.GetString([System.Convert]::FromBase64String($EncodedSecret))
  }
  $EncodedSecret = [System.Environment]::GetEnvironmentVariable("snowqaurl")
  if (![string]::IsNullOrWhiteSpace($EncodedSecret))
  {
    $url = [System.Text.Encoding]::Unicode.GetString([System.Convert]::FromBase64String($EncodedSecret))
  }
  $targetenv = "qa"
}

$cloudname = ""
switch ($cloudtag) 
{
  "Z" { $cloudname = "Azure" }
  "A" { $cloudname = "Amazon" }
  "0" { $cloudname = "VMware" }
}

$buildurl = "$($collectionurl)$($projectname)/_build/results?buildId=$($buildid)&view=results"

Write-Output "A Golden image build has failed from the $sourcebranch repository for $OSVersion in the $cloudname environment. The built computername is $VMNAME and the composer id is $CBUILDID. The builder machine is $buildername and the build url is $buildurl"
Write-Output "Opening ticket with $targetenv ($url)"

$ctype = "application/json"
$body = @"
{
  "assignment_group": "SN-SysMgt Unix Admin",
  "urgency": "2",
  "impact":"2",
  "cmdb_ci": "$buildername",
  "u_type": "incident",
  "description": "A Golden image build has failed from the $sourcebranch repository for $OSVersion in the $cloudname environment. The built computername is $VMNAME and the composer id is $CBUILDID. The builder machine is $buildername and the build url is $buildurl",
  "short_description": "$($OSVersion)$($vmss)$($cloudname) Golden Image Pipeline Build failure",
  "category": "software",
  "caller_id": "Guest Account",
  "contact_type": "Proactive Monitoring",
  "incident_state": "1"
}
"@

$pair = "$($user):$($pass)"
$encodedCreds = [System.Convert]::ToBase64String([System.Text.Encoding]::ASCII.GetBytes($pair))
$basicAuthValue = "Basic $encodedCreds"
$Headers = @{
  Authorization = $basicAuthValue
  sys_context = "rundeck"
}

$requestresult = Invoke-WebRequest -Uri $url -Headers $Headers -ContentType $ctype -Body $body -Method Post
$requestresult

$resultobject = $requestresult.Content | ConvertFrom-Json
$incident = $resultobject.result.number

Write-Output "Opened ticket number is: $incident"

<#
StatusCode        : 200
StatusDescription : OK
Content           : {"result":{"status":"success","message":"Incident has been created and assigned to application assignment group : SN-SysMgt Automation Platform","number":"INC000022003363"}}
RawContent        : HTTP/1.1 200 OK
                    Cache-Control: no-store, no-cache
                    Access-Control-Allow-Origin: *
                    Access-Control-Allow-Headers: sys_context,X-PINGOTHER,Origin,X-Correlation-ID,X-Request-ID,X-Requested-With,Accept,C…
Headers           : {[Cache-Control, System.String[]], [Access-Control-Allow-Origin, System.String[]], [Access-Control-Allow-Headers, System.String[]], [Access-Control-Max-Age, System.String[]]…}
Images            : {}
InputFields       : {}
Links             : {}
RawContentLength  : 173
RelationLink      : {}
#>

Write-Output "##vso[task.setvariable variable=targetenv;issecret=false;isOutput=true]$targetenv"
Write-Output "##vso[task.setvariable variable=incident;issecret=false;isOutput=true]$incident"