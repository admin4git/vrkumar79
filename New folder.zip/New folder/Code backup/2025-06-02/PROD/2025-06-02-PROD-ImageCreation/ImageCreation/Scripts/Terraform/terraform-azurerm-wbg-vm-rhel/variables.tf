variable "current_count" {
  type        = number
  description = "As we can't use count.index in locals, we pass it as a separate variable"
  default     = 0
}

variable "VM_ResourceGroupName" {
  type        = string
  description = "Azure Resource Group name to be used by the deployment"
}

variable "VM_Location" {
  type        = string
  description = "Azure Region name to be used by the deployment"
  default     = "East US"
}
variable "VM_Environment" {
  type        = string
  description = "The Environment value to be used for the server configuration. Allowed values: 'Production','QA','Development','Sandbox','Test'"
  default     = "Test"

  validation {
    condition     = contains(["dev", "test", "sandbox", "lab", "stage", "staging", "nonprod", "prod", "qa"], lower(var.VM_Environment))
    error_message = "The VM_Environment value must be from the following list (\"Prod\",\"QA\",\"Stage\",\"Dev\",\"Lab\",\"Test\",\"Sandbox\")."
  }
}

variable "VM_ChefRole" {
  type        = string
  description = "Chef Role defines the configuration cookbooks to be executed"
  default     = "Base"
}

variable "VM_VirtualNetworkName" {
  type        = string
  description = "Azure Virtual Network name where the machine will be connected"
}

variable "VM_VirtualNetworkRGName" {
  type        = string
  description = "Azure Resource Group name where the Virtual Network is located"
}

variable "VM_VirtualNetworkSubnetName" {
  type        = string
  description = "The name of the Subnet from the selected Virtual Network where the machine will be connected"
}

variable "VM_HostName" {
  type        = string
  description = "Name of the Virtual Machine"

  validation {
    condition     = length(var.VM_HostName) >= 2 && length(var.VM_HostName) <= 8
    error_message = "The VM_HostName value must be minimum 2, maximum 8 characters."
  }
}

variable "VM_Organization" {
  type        = string
  description = "Organization of Virtual Machine. Allowed values: 'IBRD', 'TRE', 'IFC'"
  default     = "IBRD"
  validation {
    condition     = contains(["IBRD", "TRE", "IFC"], var.VM_Organization)
    error_message = "The VM_Organization value must be from the following list (\"IBRD\",\"TRE\",\"IFC\")."
  }
}

variable "VM_HostSize" {
  type        = string
  description = "Size of the Virtual Machine"
  default     = "Standard_D2_v5"
}

variable "VM_OSVersion" {
  type        = number
  description = "OS version to be installed on the Virtual Machine. Allowed values: '7', '8', '9'"

  validation {
    condition     = contains([9, 8, 7], var.VM_OSVersion)
    error_message = "The VM_OSVersion value must be from the following list (\"7\", \"8\",\"9\")."
  }
}

variable "VM_ExistingHostGroups" {
    type = list(string)
    description = "List of existing host groups"
    default = [ "hg-newbuild-temporary" ]

    validation {
        condition = length([for group in var.VM_ExistingHostGroups : group if !startswith(group, "hg-")]) == 0
        error_message = "All Host groups must start with 'hg-'"
    }
}

variable "TAG_MissionCritical" {
  type        = string
  description = "The MissionCritical TAG is used for the server CMDB configuration. Allowed values: 'Yes', 'No'"
  default     = "No"

  validation {
    condition     = contains(["Yes", "No"], var.TAG_MissionCritical)
    error_message = "The TAG_MissionCritical value must be from the following list (\"Yes\",\"No\")."
  }
}

variable "TAG_AppType" {
  type        = string
  description = "The AppType TAG is used for the server CMDB configuration. Allowed values: 'MISC', 'WEB','DATABASE','NETWORK','APP'"

  validation {
    condition     = contains(["MISC", "WEB", "DATABASE", "NETWORK", "APP"], var.TAG_AppType)
    error_message = "The TAG_AppType value must be from the following list (\"MISC\",\"WEB\",\"DATABASE\",\"NETWORK\",\"APP\")."
  }
}

variable "TAG_Description" {
  type        = string
  description = "The Description TAG should describe the purpose of the machine"

  validation {
    condition     = length(var.TAG_Description) > 1
    error_message = "The TAG_Description value must be a description of the machine."
  }
}

variable "TAG_ClientUnit" {
  type        = string
  description = "The ClientUnit TAG must be a valid client unit in the WBG"

  validation {
    condition     = length(var.TAG_ClientUnit) > 3
    error_message = "The TAG_ClientUnit value must be a valid client unit in the WBG."
  }
}

variable "TAG_SecurityClassification" {
  type        = string
  description = "The SecurityClassification TAG is used for the server CMDB configuration. Allowed values: 'Non-Critical', 'Critical','Very Critical'"
  default     = "Non-Critical"

  validation {
    condition     = contains(["Non-Critical", "Critical", "Very Critical"], var.TAG_SecurityClassification)
    error_message = "The TAG_SecurityClassification value must be from the following list (\"Non-Critical\",\"Critical\",\"Very Critical\")."
  }
}

variable "additional_tags" {
  description = "Additional tags to be added to the VM"
  type        = map(string)
  default     = {}
}

variable "Leap" {
  description = "Leap tag is mandatory in Azure"
  type        = string
}

variable "vmname_override" {
  type    = string
  default = ""
}
variable "VM_Zone" {
  type    = list(string)
  default = null
}

variable "lunmap" {
  type = set(object({
    name                 = string
    storage_account_type = string
    size_in_gb           = number
    caching              = string
    disk_iops_read_write = optional(number)
    disk_iops_read_only  = optional(number)
    disk_mbps_read_write = optional(number)
    disk_mbps_read_only  = optional(number)
  }))
  default = [{
    name                 = "datadisk1"
    storage_account_type = "Standard_LRS"
    size_in_gb           = 100
    caching              = "ReadWrite"
  }]
}
