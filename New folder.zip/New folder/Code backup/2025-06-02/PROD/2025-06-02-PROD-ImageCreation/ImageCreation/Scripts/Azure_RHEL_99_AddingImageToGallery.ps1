connect-AzAccount -Identity -AccountId 4bf4b147-128d-41ef-9259-baae5335841a #wbgimagebuilder
select-AzSubscription -SubscriptionId "7b4d1501-6351-4d0f-a681-0473c2221a05" #WBG AZ ITSSM Prod Admin

$variablejson = get-content "$($env:VariablePath)" -Raw
$variableobj = ConvertFrom-Json $variablejson
$OSVersion = $variableobj.OSVersion
$VMSS = $variableobj.VMSS
$VMName = $variableobj.VMNAME

$location = "East US"
$resourceGroup = 'WBG-OS-Image'
$GalleryImageDefinitionName = "$OSVersion-Accredited-image-LVM"
$VMDisk = "$($VMName).vhd"
$ImageTag = "$($OSVersion)"
if($OSVersion -eq "RHEL9" -and $VMSS -eq $true)
{
	$GalleryImageDefinitionName = "VMSS-Preconfigured-RHEL9"
	$ImageTag = "$($OSVersion)VMSS"
}


$versions = Get-AzGalleryImageVersion -ResourceGroupName $resourceGroup -GalleryName SecurityAccreditedGoldImages -GalleryImageDefinitionName $GalleryImageDefinitionName
$lastversion = ""
if($null -eq $versions)
{
	$lastversion = "1900.01.1"
} else
{
	$lastversion = $versions.Name | Select-Object -Last 1
}
$lastversarr = $lastversion.Split(".")
$date = Get-Date
$monthstring = ""
$daystring = ""
$hourstring = ""
$minutestring = ""

if($date.Month -lt 10)
{
	$monthstring = "0$($date.Month)"
} else
{
	$monthstring = "$($date.Month)"
}
if($date.Day -lt 10)
{
	$daystring = "0$($date.Day)"
} else
{
	$daystring = "$($date.Day)"
}
if($date.Hour -lt 10)
{
	$hourstring = "0$($date.Hour)"
} else
{
	$hourstring = "$($date.Hour)"
}
if($date.Minute -lt 10)
{
	$minutestring = "0$($date.Minute)"
} else
{
	$minutestring = "$($date.Minute)"
}
$versionstring = "$($date.Year).$($monthstring).01"

if($date.Year -eq $lastversarr[0])
{
	if($monthstring -eq $lastversarr[1])
	{
		$nextversionnumber = [int]$lastversarr[2]+1
		if($nextversionnumber -lt 10)
		{
			$nextversionnumber = "0$($nextversionnumber)"
		}
		$versionstring = "$($date.Year).$($monthstring).$($nextversionnumber)"
	}
}
#$versionstring

$ImageName = "DO-NOT-DELETE-$($ImageTag)-Accredited-image-$($date.Year)$($monthstring)$($daystring)$($hourstring)$($minutestring)-eastus"
$existingimage = Get-AzImage -Name $ImageName
if($null -ne $existingimage)
{
    Remove-AzImage -ResourceGroupName $existingimage.ResourceGroupName -ImageName $existingimage.Name -Force
}
$imageConfig = New-AzImageConfig -Location $location -HyperVGeneration V2
$osDiskVhdUri = "https://wbgosbuildimagestorage.blob.core.windows.net/rhelimages/$($VMDisk)"
Set-AzImageOsDisk -Image $imageConfig -OsType Linux -OsState 'Generalized' -BlobUri $osDiskVhdUri
Write-Output "Creating new Image '$ImageName' from the created disk..."
$image = New-AzImage -Image $imageConfig -ImageName $ImageName -ResourceGroupName $resourceGroup

Write-Output "Adding new Image version '$versionstring' to the '$GalleryImageDefinitionName'..."
New-AzGalleryImageVersion -ResourceGroupName $resourceGroup -GalleryName SecurityAccreditedGoldImages -GalleryImageDefinitionName $GalleryImageDefinitionName -Location $location -Name $versionstring -SourceImageId $image.Id
