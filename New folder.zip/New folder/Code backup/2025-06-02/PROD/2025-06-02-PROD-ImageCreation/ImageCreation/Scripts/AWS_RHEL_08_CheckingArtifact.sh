#!/bin/bash
result=$(cat "$1")
OSVersion=$(jq -r '.OSVERSION' <<< "${result}")
VMSS=$(jq -r '.VMSS' <<< "${result}")
VMNAME=$(jq -r '.VMNAME' <<< "${result}")
IMAGE_ID=$(jq -r '.IMAGE_ID' <<< "${result}")

echo "Loading Artifact variables as Azure Devops variables"
echo "##vso[task.setvariable variable=OSVersion;issecret=false]$OSVersion"
echo "##vso[task.setvariable variable=VMNAME;issecret=false]$VMNAME"
echo "##vso[task.setvariable variable=VMSS;issecret=false]$VMSS"
echo "##vso[task.setvariable variable=IMAGE_ID;issecret=false]$IMAGE_ID"
