#!/bin/bash
set -e

# shellcheck disable=2154
GOVC_URL=$(echo "$GOVC_URL" | base64 --decode)
export GOVC_URL

case $VMNAME in
    "W0LXTGLDR8T1")    echo "Skipping image removal" ;;
    "W0LXTGLDR9T1")    echo "Skipping image removal" ;;
    *)                 rm -rf "/Data/govc/$VMNAME.vmdk"
                       echo "Trying to downloading image file to /Data/govc/${VMNAME}.vmdk..."
                       composer-cli compose image "$COMPSER_BUILDID" --filename "/Data/govc/$VMNAME.vmdk" -j | jq -r '""'
                       echo "Removing composed osbuild image ${COMPSER_BUILDID}..."
                       composer-cli compose delete "$COMPSER_BUILDID" -j | jq -r '""' ;;
esac

echo "Importing image file..."
govc import.vmdk "/Data/govc/$VMNAME.vmdk"

# shellcheck disable=2154
case $OSVersion in
    "RHEL8")    echo "RHEL8 selected"
                MACHINEIP="10.185.202.180" ;;
    "RHEL9")    echo "RHEL9 selected"
                MACHINEIP="10.185.202.131" ;;
    *)          echo "##vso[,task.logissue type=error]WRONG OS SELECTED" >&2
                exit 1 ;;
esac

case $VMNAME in
    "W0LXTGLDR8T1")    echo "W0LXTGLDR8T1 RHEL8 selected"
                       MACHINEIP="10.185.202.181" ;;
    "W0LXTGLDR9T1")    echo "W0LXTGLDR9T1 RHEL9 selected"
                       MACHINEIP="10.185.202.245" ;;
esac
#W0LXTGLDR8T1
#MACHINEIP="10.185.202.181"
 
#W0LXTGLDR9T1
#MACHINEIP="10.185.202.245"

echo "Creating VM..."
govc vm.create -net.adapter=vmxnet3 -m=4096 -c=2 -g="${OSVersion,,}_64Guest" -firmware=efi -disk="$VMNAME/$VMNAME.vmdk" -disk.controller=scsi -on=false "$VMNAME"
govc vm.customize -dns-server 138.220.4.4,138.220.8.8 -dns-suffix "worldbank.org ifc.org" -domain "worldbank.org" -gateway "10.185.203.254" -ip "$MACHINEIP" -netmask 255.255.254.0  -name "$VMNAME" -type=Linux -tz "America/New_York" -vm="$VMNAME"
govc vm.power -on "$VMNAME"

echo "$VMNAME is powered on and the ip address is $MACHINEIP"

echo "##vso[task.setvariable variable=TESTVM_IP;issecret=false;isOutput=true]${MACHINEIP}"
JSON_STRING=$( jq -n \
                  --arg os "$OSVersion" \
                  --arg vm "$VMNAME" \
                  --arg img "$(hostname)/Data/govc/$VMNAME.vmdk" \
                  --arg vmss "$VMSS" \
                  '{OSVERSION: $os, VMSS: $vmss, VMNAME: $vm, IMAGE_LOCATION: $img}' )
echo "$JSON_STRING" > variable.json
