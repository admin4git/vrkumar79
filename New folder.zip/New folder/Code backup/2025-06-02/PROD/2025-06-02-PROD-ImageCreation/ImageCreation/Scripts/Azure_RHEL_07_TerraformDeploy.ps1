connect-AzAccount -Identity -AccountId 4bf4b147-128d-41ef-9259-baae5335841a #wbgimagebuilder
select-AzSubscription -SubscriptionId "7b4d1501-6351-4d0f-a681-0473c2221a05" #WBG AZ ITSSM Prod Admin
$resourceGroup = 'WBG-OS-Image'
$VMName = "$($env:VMNAME)"
$location = "East US"

$vmobj = Get-AzVM -Name $VMName -ResourceGroupName $resourceGroup -ErrorAction SilentlyContinue
if($null -ne $vmobj)
{
    $imageid = $vmobj.StorageProfile.ImageReference.Id
    $imagearray = $imageid.Split('/')
    $imagename = $imagearray[$imagearray.Count-1]

    Write-Output "Removing Test Image '$imagename'... "
    Remove-AzImage -ResourceGroupName $resourceGroup -ImageName $imagename -Force
    Write-Output "Creating new Image '$VMName' from the test machine..."
    Stop-AzVM -ResourceGroupName $resourceGroup -Name $VMName -Force
    $imageConfig = New-AzImageConfig -Location $location -SourceVirtualMachineId $vmobj.Id -HyperVGeneration V2
    
    Set-AzVm -ResourceGroupName $resourceGroup -Name $VMName -Generalized
    $image = New-AzImage -ImageName $imageName -ResourceGroupName $resourceGroup -Image $imageConfig

    $directory = '.\Terraform\terraform-azurerm-wbg-vm-rhel'
    # locals
    $originalfile = $directory+'\locals.tf'
    $origcontent = Get-Content $originalfile -Raw
    $lastclosingbracket = $origcontent.LastIndexOf("}")
    $newcontent = $origcontent.Insert($lastclosingbracket, '  vm_image = var.vmimage_override == "" ? data.azurerm_shared_image_version.goldimage_version.id : var.vmimage_override'+[System.Environment]::NewLine)
    $newcontent | Set-Content $originalfile

    #main
    $originalfile = $directory+'\main.tf'
    $origcontent = Get-Content $originalfile
    $lineToReplace = $origcontent | Select-String source_image_id | Select-Object -ExpandProperty Line 
    $newcontent = $origcontent | ForEach-Object {$_ -replace $lineToReplace,"  source_image_id = local.vm_image"}
    $newcontent | Set-Content $originalfile
    
    #variables
    $originalfile = $directory+'\variables.tf'
    $origcontent = Get-Content $originalfile -Raw
    $newcontent = $origcontent + [System.Environment]::NewLine + @'
variable "vmimage_override" {
    type    = string
    default = ""
}
'@
    $newcontent | Set-Content $originalfile

    #Deployment Setup
    $directory = '.\Terraform'
    $originalfile = $directory+'\main.tf'
    $origcontent = Get-Content $originalfile -Raw
    $lastclosingbracket = $origcontent.LastIndexOf("}")
    $newcontent = $origcontent.Insert($lastclosingbracket, "vmimage_override = ""$($image.id)"""+[System.Environment]::NewLine)
    $ostag=$($env:OSVersion).Substring($($env:OSVersion).Length-1,1)
    $newcontent = $newcontent.Replace(999999999999,$ostag)
    $newcontent | Set-Content $originalfile

    Set-Location $directory
    terraform init
    Invoke-Expression -Command "terraform apply -auto-approve" -ErrorAction Stop
}
else
{
    Write-Output "Cannot find test vm ($VMName)"
}
