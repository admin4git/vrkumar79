output "vm_ip" {
  value       = azurerm_linux_virtual_machine.VM.private_ip_address
  description = "The private IP address of the deployed virtual machine"
}
output "vm_hostname" {
  value       = azurerm_linux_virtual_machine.VM.name
  description = "The hostname of the deployed virtual machine"
}
output "vm_fqdn" {
  value       = "${azurerm_linux_virtual_machine.VM.name}.worldbank.org"
  description = "The full domain name of the deployed virtual machine"
}

output "vm_subnet_id" {
  value       = data.azurerm_subnet.Subnet.id
  description = "VM Subnet ID"
}

output "system_assigned_ids" {
  value       = azurerm_linux_virtual_machine.VM.identity[0].principal_id
  description = "VM system identity id"
}

output "data_disk_ids" {
  value = [for disk in azurerm_managed_disk.datadisk : disk.id]
}

output "data_disks" {
  value = azurerm_managed_disk.datadisk
}
