#Write-Output "Removing composed osbuild image $($env:COMPSER_BUILDID)..."
#composer-cli compose delete $env:COMPSER_BUILDID -j | jq -r '""'

connect-AzAccount -Identity -AccountId 4bf4b147-128d-41ef-9259-baae5335841a #wbgimagebuilder
select-AzSubscription -SubscriptionId "7b4d1501-6351-4d0f-a681-0473c2221a05" #WBG AZ ITSSM Prod Admin
$resourceGroup = 'WBG-OS-Image'
$VMName = "$($env:VMNAME)"

$vmobj = Get-AzVM -Name $VMName -ResourceGroupName $resourceGroup -ErrorAction SilentlyContinue
if($null -ne $vmobj)
{
    $osdiskname = $vmobj.StorageProfile.OsDisk.Name
    $networkid= $vmobj.NetworkProfile.NetworkInterfaces[0].Id
    $netidarray= $networkid.Split('/')
    $nicname = $netidarray[$netidarray.Count-1]
    $imageid = $vmobj.StorageProfile.ImageReference.Id
    $imagearray = $imageid.Split('/')
    $imagename = $imagearray[$imagearray.Count-1]

    Write-Output "Removing VM '$VMName'... "
    Remove-AzVM -Name $VMName -ResourceGroupName $resourceGroup -Force
    Write-Output "Removing Network Interface '$nicname'... "
    Remove-AzNetworkInterface -Name $nicname -ResourceGroupName $resourceGroup -Force
    Write-Output "Removing Managed Disk '$osdiskname'... "
    Remove-AzDisk -DiskName $osdiskname -ResourceGroupName $resourceGroup -Force
    Write-Output "Removing Test Image '$imagename'... "
    Remove-AzImage -ResourceGroupName $resourceGroup -ImageName $imagename -Force
}
else
{
    Write-Output "Test VM '$VMName' was not found, continuing"
}
