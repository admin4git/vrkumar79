#!/bin/bash
# Ensure failure on stderr
set -e

# base toml file for all rhel versions
BASE_TOML="rhel_base.toml"
AZURE_TOML="azure.toml"
# OSVersion is coming from the pipeline
# shellcheck disable=2154
BPRINTVAR="BLUEPRINT-WBG-${OSVersion}"

# Ensure that all TOML files are with Unix End-line style
# if OS file contains Windows end-line, it can break
dos2unix ./*.toml 2>&1

# OSVersion coming from Environment variable
# shellcheck disable=2154

if [ "$OSVersion" != "RHEL8" ] && [ "$OSVersion" != "RHEL9" ]
then
    echo "##vso[task.logissue type=error;]Wrong OSVersion specified" >&2
fi

# shellcheck disable=SC2154
if [ "$cloudtag" == "Z" ]
then
    cat "$AZURE_TOML" >> "${OSVersion,,}.toml"
fi

cat "$BASE_TOML" >> "${OSVersion,,}.toml"

if [ "$VMSS" == "true" ]; then
    echo "VMSS deployment selected"
    cat "${OSVersion,,}vmss.toml" >> "${OSVersion,,}.toml"
    # cat ${OSVersion,,}.toml >> ${OSVersion,,}vmss.toml
    sed -i "s/${OSVersion}/${OSVersion}VMSS/" "${OSVersion,,}.toml"
    # sed -i "s/${OSVersion}/${OSVersion}VMSS/" ${OSVersion,,}vmss.toml
    # mv ${OSVersion,,}vmss.toml ${OSVersion,,}.toml
    BPRINTVAR="BLUEPRINT-WBG-${OSVersion}VMSS"
fi

is_locked=1
while [[ $is_locked -eq 1 ]]; do
  echo "Waiting for service to start up..."
  sleep 30

  if [[ -f "/Data/.dirlock*" ]]; then
    is_locked=1
  else
    is_locked=0
  fi
done

random_number=$(shuf -i 1-100000 -n 1)
svlockvar="/Data/.svlock${random_number}"
echo "Building images, service stop is not allowed" > "$svlockvar"

echo "Pushing blueprint ${BPRINTVAR}"
if ! composer-cli blueprints push "${OSVersion,,}.toml"; then
    echo "##vso[task.logissue type=error;]Failed to push blueprint" >&2
    rm -rf "$svlockvar"
    exit 1
fi

echo "Resolving blueprint dependencies..."
if ! composer-cli blueprints depsolve "$BPRINTVAR"; then
    echo "##vso[task.logissue type=error;]Failed to depsolve blueprint" >&2
    rm -rf "$svlockvar"
    exit 1
fi

# shellcheck disable=2154
case $cloudtag in
    "Z")    echo "Azure build starting"
            #COMPSER_BUILDID=$(composer-cli --json compose start "$BPRINTVAR" vhd "$VMNAME" azure.toml | jq -r '.[].body.build_id') ;;
            COMPSER_BUILDID=$(composer-cli --json --size 153600 compose start "$BPRINTVAR" vmdk | jq -r '.[].body.build_id') ;;
    "0")    echo "VmWare build starting"
            COMPSER_BUILDID=$(composer-cli --json --size 153600 compose start "$BPRINTVAR" vmdk | jq -r '.[].body.build_id') ;;
    "A")    echo "Amazon build starting"
            COMPSER_BUILDID=$(composer-cli --json --size 153600 compose start "$BPRINTVAR" ami "$VMNAME" aws.toml | jq -r '.[].body.build_id') ;;
esac

echo "##vso[task.setvariable variable=COMPSER_BUILDID;issecret=false;isOutput=true]$COMPSER_BUILDID"
echo "##vso[task.setvariable variable=svlockvar;issecret=false;isOutput=true]/Data/.svlock${random_number}"
if [ -z "$COMPSER_BUILDID" ]
then
    rm -rf "$svlockvar"
    exit 2
fi
