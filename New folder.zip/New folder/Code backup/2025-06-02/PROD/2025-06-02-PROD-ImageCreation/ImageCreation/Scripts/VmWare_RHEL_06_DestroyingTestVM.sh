#!/bin/bash
GOVC_URL=$(echo "$GOVC_URL" | base64 --decode)
export GOVC_URL

VM=$(govc vm.info "$VMNAME")
if [ -z "$VM" ]
then
    govc datastore.rm "$VMNAME" > /dev/null 2>&1
    echo "Test VM '$VMNAME' was not found, continuing"
else
    echo "Removing Test VM '$VMNAME'..."
    govc vm.destroy "$VMNAME"
fi
