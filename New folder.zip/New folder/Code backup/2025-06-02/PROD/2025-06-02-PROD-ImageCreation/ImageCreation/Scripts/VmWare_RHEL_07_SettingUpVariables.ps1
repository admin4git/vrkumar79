$connectionToken="$env:SYSTEM_ACCESSTOKEN"
$org = "ITSEN-Collection"
$project = "Enterprise-Services"
$releaseid = "$env:Release_ReleaseId"
$urlget = "https://vsrm.dev.azure.com/$org/$project/_apis/release/releases/$($releaseid)?api-version=5.1"
$base64AuthInfo = [System.Convert]::ToBase64String([System.Text.Encoding]::ASCII.GetBytes(":$($connectionToken)"))
$getdef = Invoke-RestMethod -Headers @{Authorization=("Basic {0}" -f $base64AuthInfo)} -Method GET -ContentType application/json -Uri $urlget

##Write-Host Pipeline = $($getdef | ConvertTo-Json -Depth 100)
$GOVC_URL=@"
    {
      "value": "$env:LoadKeyvaultVariables_govcurl",
      "isSecret": true
    }
"@

#$getdef = ConvertFrom-Json $getdef
$getdef.variables | add-member -Name "GOVC_URL" -value (Convertfrom-Json $GOVC_URL) -MemberType NoteProperty -Force -PassThru

$getdef = $getdef | ConvertTo-Json -Depth 100
#$getdef | clip
$urlput = "https://vsrm.dev.azure.com/$org/$project/_apis/release/releases/$($releaseid)?api-version=5.1"
$null = Invoke-RestMethod -Uri $urlput -Method PUT -Body $getdef -ContentType "application/json" -Headers @{Authorization=("Basic {0}" -f $base64AuthInfo)}
