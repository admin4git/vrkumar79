#connect-AzAccount -Identity -AccountId 4bf4b147-128d-41ef-9259-baae5335841a #wbgimagebuilder

#select-AzSubscription -SubscriptionId "7b4d1501-6351-4d0f-a681-0473c2221a05" #WBG AZ ITSSM Prod Admin
#select-AzSubscription -SubscriptionId "64c555a9-193a-4e08-af9d-daaa32034faa"

Write-Output "Hostname: $(hostname)"

$resourceGroup = 'WBG-OS-Image'
$VMName = "$($env:VMNAME)"
$OSVersion = "$($env:OSVersion)"
$INAME = "$($env:IMAGENAME)"
$IMAGENAME = "$($env:IMAGENAME)"
$location = "East US"
$imageid = "$($env:imageid)"

Write-Output "-- VMNAME '$VMName' --"
Write-Output "-- OS Version '$OSVersion' --"
Write-Output "-- image id '$imageid' -- "

Write-Output "-- I Name '$INAME' ---"

Write-Output "Image Name == '$imagename' "

Write-Output "Image Name caps == '$IMAGENAME' "

Write-Host "Image Name caps == $IMAGENAME "

$galleryName = "SecurityAccreditedGoldImages"
$imageDefinition = "RHEL8-Accredited-image-LVM"

Write-Output "Fetching latest image version from Azure Compute Gallery..."
$imageVersion = Get-AzGalleryImageVersion `
    -ResourceGroupName $resourceGroup `
    -GalleryName $galleryName `
    -GalleryImageDefinitionName $imageDefinition `
#    | Where-Object { $_.PublishingProfile.IsLatest -eq $true }
    | Sort-Object -Property Name -Descending `
    | Select-Object -First 1

if ($null -eq $imageVersion) {
    throw "Error: Could not find image version for '$imageDefinition' in gallery '$galleryName'"
    throw "Error: No image version marked as latest for '$imageDefinition' in gallery '$galleryName'."
}

$imageid = $imageVersion.Id

Write-Output "-- VMNAME '$VMName' --"
Write-Output "-- image id '$imageid' -- "

   $ostag = $env:OSVersion.Substring($env:OSVersion.Length - 1, 1)
   Write-Output "-- OS TAG '$ostag' -- "

#-------------------------- set OS Version
$directory = '.\Azure-Test-TF'
    $originalfile = $directory+'\terraform.tfvars'
    $origcontent = Get-Content $originalfile -Raw
    #$lastclosingbracket = $origcontent.LastIndexOf("}")
    #$newcontent = $origcontent.Insert($lastclosingbracket, "vmimage_override = ""$($image.id)"""+[System.Environment]::NewLine)
    $ostag = $env:OSVersion.Substring($env:OSVersion.Length - 1, 1)
    $newcontent = $origcontent.Replace("8or9", $ostag)
    $newcontent | Set-Content $originalfile

    $originalfile = $directory+'\provider.tf'
    $origcontent = Get-Content $originalfile -Raw
    #$lastclosingbracket = $origcontent.LastIndexOf("}")
    #$newcontent = $origcontent.Insert($lastclosingbracket, "vmimage_override = ""$($image.id)"""+[System.Environment]::NewLine)
    $ostag = $env:OSVersion.Substring($env:OSVersion.Length - 1, 1)
    $newcontent = $origcontent.Replace("RHEL8or9", $OSVersion)
    $newcontent | Set-Content $originalfile


#---------------------
# Deployment Setup
#-$directory = '.\Azure-Test-TF'
Set-Location $directory
#terraform refresh
terraform init
#terraform plan
Invoke-Expression -Command "terraform apply -auto-approve" -ErrorAction Stop

$TARGETVMNAME = terraform show -json | jq -r '.values.root_module.child_modules[].resources[] | select(.type == "azurerm_linux_virtual_machine") | .values.computer_name'

Write-Host "VM Hostname: $TARGETVMNAME"

Write-Output "##vso[task.setvariable variable=TARGETVMNAME;isOutput=true]$TARGETVMNAME"

<#

#$vmobj = Get-AzVM -Name $VMName -ResourceGroupName $resourceGroup -ErrorAction SilentlyContinue
#if($null -ne $vmobj)
#{
    #$imageid = $vmobj.StorageProfile.ImageReference.Id
    $imagearray = $imageid.Split('/')
    $imagename = $imagearray[$imagearray.Count-1]

    Write-Output "Removing Test Image '$imagename'... "
    #Remove-AzImage -ResourceGroupName $resourceGroup -ImageName $imagename -Force
    Write-Output "Creating new Image '$VMName' from the test machine..."
    #Stop-AzVM -ResourceGroupName $resourceGroup -Name $VMName -Force
    $imageConfig = New-AzImageConfig -Location $location -SourceVirtualMachineId $vmobj.Id -HyperVGeneration V2
    
    #Set-AzVm -ResourceGroupName $resourceGroup -Name $VMName -Generalized
    #$image = New-AzImage -ImageName $imageName -ResourceGroupName $resourceGroup -Image $imageConfig
    $image = $imagename

    $directory = '.\Azure-Test-TF'
    <--#
    # locals
    $originalfile = $directory+'\locals.tf'
    $origcontent = Get-Content $originalfile -Raw
    $lastclosingbracket = $origcontent.LastIndexOf("}")
    $newcontent = $origcontent.Insert($lastclosingbracket, '  vm_image = var.vmimage_override == "" ? data.azurerm_shared_image_version.goldimage_version.id : var.vmimage_override'+[System.Environment]::NewLine)
    $newcontent | Set-Content $originalfile

    #main
    $originalfile = $directory+'\main.tf'
    $origcontent = Get-Content $originalfile
    $lineToReplace = $origcontent | Select-String source_image_id | Select-Object -ExpandProperty Line 
    $newcontent = $origcontent | ForEach-Object {$_ -replace $lineToReplace,"  source_image_id = local.vm_image"}
    $newcontent | Set-Content $originalfile
    #-->
    #variables
    $originalfile = $directory+'\variables.tf'
    $origcontent = Get-Content $originalfile -Raw
    $newcontent = $origcontent + [System.Environment]::NewLine + @'
variable "vmimage_override" {
    type    = string
    default = ""
}
'@
    $newcontent | Set-Content $originalfile

    #Deployment Setup
    $directory = '.\Azure-Test-TF'
<#
    $originalfile = $directory+'\vms.tf'
    $origcontent = Get-Content $originalfile -Raw
    $lastclosingbracket = $origcontent.LastIndexOf("}")
    #$newcontent = $origcontent.Insert($lastclosingbracket, "vmimage_override = ""$($image.id)"""+[System.Environment]::NewLine)
    $ostag=$($env:OSVersion).Substring($($env:OSVersion).Length-1,1)
    $newcontent = $newcontent.Replace(999999999999,$ostag)
    $newcontent | Set-Content $originalfile
#-->
    Set-Location $directory
    terraform init
    Invoke-Expression -Command "terraform apply -auto-approve" -ErrorAction Stop
#}
#else
#{
    Write-Output "Cannot find test vm ($VMName)"
#}

#>