connect-AzAccount -Identity -AccountId 4bf4b147-128d-41ef-9259-baae5335841a #wbgimagebuilder
select-AzSubscription -SubscriptionId "7b4d1501-6351-4d0f-a681-0473c2221a05" #WBG AZ ITSSM Prod Admin
$resourceGroup = 'WBG-OS-Image'
$VMName = "$($env:VMNAME)"
$OSVersion = "$($env:OSVersion)"
$INAME = "$($env:IMAGENAME)"
$IMAGENAME = "$($env:IMAGENAME)"
$location = "East US"
$imageid = "$($env:imageid)"

Write-Output "-- VMNAME '$VMName' --"
Write-Output "-- OS Version '$OSVersion' --"
Write-Output "-- image id '$imageid' -- "

Write-Output "-- I Name '$INAME' ---"

Write-Output "Image Name == '$imagename' "

Write-Output "Image Name caps == '$IMAGENAME' "

Write-Host "Image Name caps == $IMAGENAME "

$galleryName = "SecurityAccreditedGoldImages"
$imageDefinition = "RHEL8-Accredited-image-LVM"

Write-Output "Fetching latest image version from Azure Compute Gallery..."
$imageVersion = Get-AzGalleryImageVersion `
    -ResourceGroupName $resourceGroup `
    -GalleryName $galleryName `
    -GalleryImageDefinitionName $imageDefinition `
#    | Where-Object { $_.PublishingProfile.IsLatest -eq $true }
    | Sort-Object -Property Name -Descending `
    | Select-Object -First 1

if ($null -eq $imageVersion) {
    throw "Error: Could not find image version for '$imageDefinition' in gallery '$galleryName'"
    throw "Error: No image version marked as latest for '$imageDefinition' in gallery '$galleryName'."
}

$imageid = $imageVersion.Id

Write-Output "-- VMNAME '$VMName' --"
Write-Output "-- image id '$imageid' -- "

   $ostag = $env:OSVersion.Substring($env:OSVersion.Length - 1, 1)
   Write-Output "-- OS TAG '$ostag' -- "


$directory = '.\Azure-Test-TF'
#-------------------------- set OS Version
    $originalfile = $directory+'\terraform.tfvars'
    $origcontent = Get-Content $originalfile -Raw
    #$lastclosingbracket = $origcontent.LastIndexOf("}")
    #$newcontent = $origcontent.Insert($lastclosingbracket, "vmimage_override = ""$($image.id)"""+[System.Environment]::NewLine)
    $ostag = $env:OSVersion.Substring($env:OSVersion.Length - 1, 1)
    $newcontent = $origcontent.Replace("8or9", $ostag)
    $newcontent | Set-Content $originalfile

    $originalfile = $directory+'\provider.tf'
    $origcontent = Get-Content $originalfile -Raw
    #$lastclosingbracket = $origcontent.LastIndexOf("}")
    #$newcontent = $origcontent.Insert($lastclosingbracket, "vmimage_override = ""$($image.id)"""+[System.Environment]::NewLine)
    $ostag = $env:OSVersion.Substring($env:OSVersion.Length - 1, 1)
    $newcontent = $origcontent.Replace("RHEL8or9", $OSVersion)
    $newcontent | Set-Content $originalfile


Set-Location $directory
terraform init
terraform destroy -auto-approve