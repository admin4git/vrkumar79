
#-------------------------------------------------- 12-Feb-2025 -- original

#!/bin/bash

timestamp=$(date +"%Y%m%d%H%M")
ImageName="DO-NOT-DELETE-$OSVersion-Accredited-image-$timestamp-eastus"

echo "Creating a copy of temporary image $IMAGE_ID with the name of $ImageName"
newimageid=$(aws ec2 copy-image --name "$ImageName" --source-image-id "$IMAGE_ID" --description "Accredited Unix Golden Image $OSVersion" --region us-east-1 --source-region us-east-1 | jq .ImageId)

echo "Adding tags to the copied image $newimageid"
aws ec2 create-tags --resources "$newimageid" --tags Key=CreatedBy,Value=RHELBuilder Key=AMI,Value="$OSVersion"

echo "Using $newimageid to distribute $OSVersion"

mapfile -t arr < <(aws organizations list-accounts | jq -r '.Accounts[].Id')

len=${#arr[@]}
counter=0
for i in "${arr[@]}"
do
        $counter++
        echo "Distributing to accountid ${i} ${counter}/${len}"
        aws ec2 modify-image-attribute --image-id "$newimageid" --launch-permission "Add=[{UserId=$i}]"
done


#--------------------------------------------------- Hema provided and updated on 12-Fen-2025

#!/bin/bash

timestamp=$(date +"%Y%m%d%H%M")
ImageName="DO-NOT-DELETE-$OSVersion-Accredited-image-$timestamp-eastus"

echo "Creating a copy of temporary image $IMAGE_ID with the name of $ImageName"
newimageid=$(aws ec2 copy-image --name "$ImageName" --source-image-id "$IMAGE_ID" --description "Accredited Unix Golden Image $OSVersion" --region us-east-1 --source-region us-east-1 | jq -r .ImageId)

# Check if the image ID is empty
if [ -z "$newimageid" ]; then
    echo "Failed to get the new image ID. Exiting script."
    exit 1
fi

echo "Created new image $newimageid"

echo "Adding tags to the copied image $newimageid"
aws ec2 create-tags --resources "$newimageid" --tags Key=CreatedBy,Value=RHELBuilder Key=AMI,Value="$OSVersion"

echo "Using $newimageid to distribute $OSVersion"

mapfile -t arr < <(aws organizations list-accounts | jq -r '.Accounts[].Id')

len=${#arr[@]}
counter=0
for i in "${arr[@]}"
do
    ((counter++))
    echo "Distributing to accountid ${i} ${counter}/${len}"
    aws ec2 modify-image-attribute --image-id "$newimageid" --launch-permission "Add=[{UserId=$i}]"
done

