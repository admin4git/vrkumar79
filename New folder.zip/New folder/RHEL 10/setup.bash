



wget  https://packages.microsoft.com/rhel/10/prod/Packages/p/packages-microsoft-prod-1.1-3.noarch.rpm

# Example for a specific version (replace with the latest stable version)
wget https://github.com/PowerShell/PowerShell/releases/download/v7.5.0/powershell-7.5.0-1.rh.x86_64.rpm
sudo dnf install ./powershell-7.5.0-1.rh.x86_64.rpm -y


# Sudo access

vim /etc/sudoers.d/srvtfs

%srvtfs ALL=NOPASSWD:/usr/bin/rm -rf /var/lib/osbuild-composer/artifacts/*
%srvtfs ALL=NOPASSWD:/usr/bin/systemctl stop osbuild\*
%srvtfs ALL=NOPASSWD:/usr/bin/systemctl reset-failed osbuild\*
%srvtfs ALL=NOPASSWD:/usr/bin/systemctl start osbuild-composer.socket
%srvtfs ALL=NOPASSWD:/usr/bin/rm -rf /var/cache/osbuild-worker/*
%srvtfs ALL=NOPASSWD:/usr/bin/rm -rf /var/cache/osbuild-composer/*
%srvtfs ALL=NOPASSWD:/usr/bin/chattr *
%srvtfs ALL=NOPASSWD:/usr/sbin/subscription-manager *
%srvtfs ALL=NOPASSWD:/usr/bin/yum reinstall packages-microsoft-prod.rpm -y
%srvtfs ALL=NOPASSWD:/usr/bin/yum check-update
%srvtfs ALL=NOPASSWD:/usr/bin/chown _osbuild-composer\: REPO -R
%srvtfs ALL=NOPASSWD:/usr/bin/createrepo .
%srvtfs ALL=NOPASSWD:/usr/bin/systemctl restart osbuild-composer.service
%srvtfs ALL=NOPASSWD:/usr/bin/rm -rf /Data/REPO/*
srvtfs ALL=(ALL) NOPASSWD: /bin/rm -f /var/cache/osbuild-worker/*



chmod 600 /etc/sudoers.d/srvtfs

#--------------------------------

dnf install dos2unix

#------------------------------------ Add local repo

vim /Data/local-repo.toml

check_gpg = false
check_repogpg = false
check_ssl = false
id = "local_repo"
name = "local_repo"
rhsm = false
system = false
type = "yum-baseurl"
url = "file:///Data/REPO/"


composer-cli sources add /Data/local-repo.toml

[root@w0lxpgldagnt04 ~]# composer-cli sources list
appstream
baseos
local_repo

#-------------------------------------------------

python -m pip install argparse		
python -m pip install datetime
python -m pip install ipaddress
python -m pip install requests
python -m pip install paramiko

#------------------------ chef-inspec

# add server ip in 

vim /etc/ssh/sshd_config.d/99-chef-inspec.conf

# in all Match Address entry

systemctl restart sshd


------------- install pending --
govc 
inspec  -- RHEL 9 profile

--- issues
	
vm guest not support for RHEL10_64










